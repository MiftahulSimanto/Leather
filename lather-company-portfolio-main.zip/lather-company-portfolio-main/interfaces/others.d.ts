interface IBreadcrumbItem {
  label: string;
  href?: string; // optional, last item won't have href
}

interface ICategory {
  id: string;
  title: string;
  description: string;
  image: string | StaticImageData;
  href: string;
}
