"use client";
import { automotiveCatImg, aviationCatImg, nauticalCatImg } from "@/assets";
import CategoryLayout from "@/components/sections/category-layout";
import ContentImageSection from "@/components/sections/content-image-section";
import HomeHeroSection from "@/components/sections/hero-section/home-hero-section";
import LeanImageStackPreviewer from "@/components/sections/lean-img-stack-previewer";
import SecondaryDescriptionSection from "@/components/sections/secondary-description";
import withShutter from "@/components/sections/shutter";

const Home = () => {
  const categories = [
    {
      id: "nautical",
      title: "Nautical",
      description:
        "Elegance and durability, a binomial that guarantees that the leathers we supply for sophisticated boats are characterised by timeless charm.",
      image: nauticalCatImg,
      href: "/categories/nautical",
    },
    {
      id: "aviation",
      title: "Aviation",
      description:
        "Luxury in the skies, with elegant and resistant leathers that meet the strictest safety and maintenance standards.",
      image: aviationCatImg,
      href: "/categories/aviation",
    },
    {
      id: "regenerated",
      title: "Regenerated Materials",
      description:
        "We turn scraps into resources, combining elegance and sustainability in new materials synonymous with environmental responsibility.",
      image: automotiveCatImg,
      href: "/categories/regenerated",
    },
    {
      id: "nautical",
      title: "Nautical",
      description:
        "Elegance and durability, a binomial that guarantees that the leathers we supply for sophisticated boats are characterised by timeless charm.",
      image: nauticalCatImg,
      href: "/categories/nautical",
    },
    {
      id: "aviation",
      title: "Aviation",
      description:
        "Luxury in the skies, with elegant and resistant leathers that meet the strictest safety and maintenance standards.",
      image: aviationCatImg,
      href: "/categories/aviation",
    },
    {
      id: "regenerated",
      title: "Regenerated Materials",
      description:
        "We turn scraps into resources, combining elegance and sustainability in new materials synonymous with environmental responsibility.",
      image: automotiveCatImg,
      href: "/categories/regenerated",
    },
  ];
  return (
    <>
      <HomeHeroSection
        title="Leather Craftsmanship Redefined"
        description="We believe in crafting leather with passion and precision, delivering  quality and timeless elegance in every piece."
      />
      <CategoryLayout categories={categories} />
      <SecondaryDescriptionSection
        subTitle="Our Philosophy"
        title="Where Tradition Meets Innovation"
        description="<p>At the heart of our craft lies a profound respect for traditional leatherworking techniques, passed down through generations of master artisans. Each piece we create is a testament to timeless quality and meticulous attention to detail.</p><p>We believe that true luxury is found not in fleeting trends, but in the enduring beauty of materials that age gracefully, developing character and patina over time. Our commitment is to create products that become cherished companions on life's journey.</p>"
      />
      <ContentImageSection
        title="Sustainable Practices"
        subTitle="Our Commitment"
        description="<p>Sustainability is at the heart of everything we do. We work exclusively with tanneries that follow environmentally responsible practices, ensuring minimal impact on our planet.</p><p>Each leather hide is carefully selected and processed using traditional methods that have been refined over generations, creating products that are not only beautiful but also ethically made.</p>"
        imageSrc="https://images.unsplash.com/photo-1598532163257-ae3c6b2524b6?auto=format&fit=crop&w=1200&q=80"
        imageAlt="Sustainable leather tanning process"
        position="rightToLeft"
        cta={{
          label: "Learn More",
          onClick: () => console.log("CTA clicked"),
        }}
      />
      <LeanImageStackPreviewer />
    </>
  );
};

export default withShutter(Home);
