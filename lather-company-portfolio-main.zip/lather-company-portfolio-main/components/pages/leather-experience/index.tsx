"use client";
import CareAndCleaning from "@/components/sections/careAndCleaning";
import HeroSection from "@/components/sections/hero-section";
import LatherCharacteristicsSection from "@/components/sections/leather-characteristics-section";
import LeatherHistorySection from "@/components/sections/leather-history-section";
import LeatherMeaningSection from "@/components/sections/leather-meaning-section";
import LeatherProductionProcessSection from "@/components/sections/leather-production-process-section";
import withShutter from "@/components/sections/shutter";
import SustainabilitySection from "@/components/sections/sustainability-section";

const LeatherExperienceComp = () => {
  return (
    <>
      <HeroSection
        title="Our Leather Experience"
        description="  Leather is a material that boasts centuries of tradition, which we
          treat with love and increasingly refined techniques to enhance its
          unique characteristics."
        breadcrumb={[
          { label: "Home", href: "/" },
          { label: "Leather Experience", href: "/" },
        ]}
      />
      <LatherCharacteristicsSection />
      <LeatherHistorySection />
      <SustainabilitySection />
      <LeatherMeaningSection />
      <LeatherProductionProcessSection />
      <CareAndCleaning />
    </>
  );
};

export default withShutter(LeatherExperienceComp);
