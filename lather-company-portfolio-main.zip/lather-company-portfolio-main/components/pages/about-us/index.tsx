"use client";

import { peopleImg, withClient } from "@/assets";
import AboutUs from "@/components/sections/about-us";
import ClientReview from "@/components/sections/client-review";
import ContentImageSection from "@/components/sections/content-image-section";
import HeroSection from "@/components/sections/hero-section";
import MasterLeatherCraftsman from "@/components/sections/master-leather-craftsman";
import OurTargetSector from "@/components/sections/our-target-sector";
import withShutter from "@/components/sections/shutter";
import React from "react";

const AboutUsComp = () => {
  return (
    <>
      <HeroSection
        title="About Us"
        description="We at Gruppo Mastrotto are committed to becoming partners in your creative process, working together with you to ensure that every item reflects your vision and meets the highest quality standards."
        breadcrumb={[
          { label: "Home", href: "/" },
          { label: "about us", href: "/about-us" },
        ]}
      />

      <AboutUs />
      <OurTargetSector />
      <ClientReview />
      <ContentImageSection
        title="Respect for the environment, a corporate priority"
        subTitle="Our commitment to sustainability"
        description="<p>
       Our operations are guided by respect for everything around us, with an active commitment to environmental sustainability issues. We take particular care of our impact on the environment by making careful use of resources such as water and energy, focusing on waste reduction, constantly striving to reuse and proper waste management.
        </p>
        <p>In this way, we aim to build a better future for people, communities and new generations.</p>
        "
        imageSrc={withClient}
        imageAlt="Sustainability Journey"
        cta={{
          label: "Learn More",
          onClick: () => console.log("CTA Clicked"),
        }}
      />
      <ContentImageSection
        position="rightToLeft"
        title="The most important capital: people"
        subTitle="Our commitment to sustainability"
        description="<p>
       Our employees are the beating heart of our business. We are committed to creating a safe and stimulating working environment, where everyone can express their potential, focusing considerable attention on inclusion and wellbeing.</p>
        <p>Working at Gruppo Mastrotto means being part of a project of professional and personal growth, focusing on continuous improvement and future-oriented challenges, in which we can imagine and create what does not yet exist.</p>
        "
        imageSrc={peopleImg}
        imageAlt="Sustainability Journey"
        cta={{
          label: "Learn More",
          onClick: () => console.log("CTA Clicked"),
        }}
      />
      <MasterLeatherCraftsman />
    </>
  );
};

export default withShutter(AboutUsComp);
