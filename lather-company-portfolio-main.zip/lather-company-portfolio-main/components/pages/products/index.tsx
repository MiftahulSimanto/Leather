"use client";
import AboutProductSection from "@/components/sections/about-product";
import HeroSection from "@/components/sections/hero-section";
import MakingProcess from "@/components/sections/making-process";
import PhotoGallery from "@/components/sections/photo-gallery";
import withShutter from "@/components/sections/shutter";
import React from "react";

const ProductsComp = () => {
  return (
    <>
      <HeroSection
        title="Leather Categories We Offer"
        description="We at Gruppo Mastrotto are committed to becoming partners in your creative process, working together with you to ensure that every item reflects your vision and meets the highest quality standards."
        breadcrumb={[
          { label: "Home", href: "/" },
          { label: "Products", href: "/products" },
        ]}
      />
      <AboutProductSection />
      <PhotoGallery />
      <MakingProcess />
    </>
  );
};

export default withShutter(ProductsComp);
