"use client";
import ContactDetails from "@/components/sections/contact-details";
import DescriptionSection from "@/components/sections/description-section";
import HeroSection from "@/components/sections/hero-section";
import withShutter from "@/components/sections/shutter";

const ContactUsComp = () => {
  return (
    <>
      <HeroSection
        title="Contact Us"
        description="We at Gruppo Mastrotto are committed to becoming partners in your creative process, working together with you to ensure that every item reflects your vision and meets the highest quality standards."
        breadcrumb={[
          { label: "Home", href: "/" },
          { label: "contact us", href: "/contact-us" },
        ]}
      />
      <section className="w-full flex flex-col bg-[#e8e4e1] py-16 px-4 md:px-16">
        <DescriptionSection
          subTitle="Trade network"
          title="Close to you, all over the world"
          description="<p> Our presence in the world is guaranteed by a network of selected qualified partners. Choose your area on the map below and find your nearest Gruppo Mastrotto representative.</p>
         <p> N.B. If the search does not yield any results, please contact us using the form below.
 </p>"
        />
      </section>
      <ContactDetails />
    </>
  );
};

export default withShutter(ContactUsComp);
