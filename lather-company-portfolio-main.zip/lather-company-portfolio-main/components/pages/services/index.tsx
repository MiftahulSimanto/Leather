"use client";
import BusinessPartnership from "@/components/sections/business-partnership";
import FinishingAndEmbossingSection from "@/components/sections/finishing-and-embossing-section";
import HeroSection from "@/components/sections/hero-section";
import KeyBenefitsSection from "@/components/sections/key-benefits";
import LogisticsAndShipment from "@/components/sections/logistics-and-shipment";
import PartnershipValue from "@/components/sections/partnership-value";
import QualityReadyDelivery from "@/components/sections/quality-ready-delivery";
import withShutter from "@/components/sections/shutter";
import React from "react";

const ServicesComp = () => {
  return (
    <>
      <HeroSection
        title="Our Services"
        description="At Excellent Leather Agency, we provide complete leather sourcing, quality control, and export management services for international buyers."
        breadcrumb={[
          { label: "Home", href: "/" },
          { label: "Services", href: "/services" },
        ]}
      />
      <PartnershipValue />
      <QualityReadyDelivery />

      <FinishingAndEmbossingSection />
      <LogisticsAndShipment />

      <KeyBenefitsSection />
      <BusinessPartnership />

      <section className="relative overflow-hidden bg-[#e6ddd6] px-4 py-16 md:px-8 md:py-24">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.7),transparent_55%)]" />

        <div className="relative mx-auto max-w-6xl rounded-3xl border border-[#c8bcb2] bg-[#f8f5f2] p-6 shadow-[0_18px_40px_rgba(64,42,24,0.12)] md:p-10">
          <div className="grid gap-8 md:grid-cols-[1fr_auto] md:items-center">
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-[0.22em] text-[#7d6451]">
                Partnership Commitment
              </p>
              <p className="text-lg leading-relaxed text-[#2f241c] md:text-[1.35rem]">
                At <b>Excellent Leather Agency</b>, we focus on long-term
                business relationships built on trust, consistent quality, and
                reliable service. We proudly maintain regular and long-standing
                customers from both Europe and Asia, reflecting our commitment
                to sustainable partnerships and dependable leather export from
                Bangladesh.
              </p>
            </div>

            <div className="flex flex-row flex-wrap gap-3 md:max-w-[200px] md:flex-col md:justify-center">
              <span className="rounded-full border border-[#bba998] bg-white px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#5d4634]">
                Global Buyers
              </span>
              <span className="rounded-full border border-[#bba998] bg-white px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#5d4634]">
                Long-Term Trust
              </span>
              <span className="rounded-full border border-[#bba998] bg-white px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#5d4634]">
                Reliable Export
              </span>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default withShutter(ServicesComp);
