"use client";
import React from "react";
import Link from "next/link";

type Props = {
  items: IBreadcrumbItem[];
};

const Breadcrumb = ({ items }: Props) => {
  return (
    <nav className=" top-4 left-4 text-white text-sm flex gap-2">
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {item.href && index !== items.length - 1 ? (
            <Link
              href={item.href}
              className="hover:underline hover:text-gray-200 transition"
            >
              {item.label}
            </Link>
          ) : (
            <span className="text-gray-300">{item.label}</span>
          )}
          {index < items.length - 1 && <span>•</span>}
        </React.Fragment>
      ))}
    </nav>
  );
};

export default Breadcrumb;
