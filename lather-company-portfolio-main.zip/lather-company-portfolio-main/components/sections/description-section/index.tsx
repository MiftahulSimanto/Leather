"use client";

import { sanitizeHTML } from "@/utils/sanitize";
import React, { useEffect, useState } from "react";

type Props = {
  title: string;
  subTitle?: string;
  description: string;
  contentClassName?: string;
};

const DescriptionSection = ({
  title,
  subTitle,
  description,
  contentClassName,
}: Props) => {
  const [desc, setDesc] = useState<string | undefined>();

  useEffect(() => {
    setDesc(sanitizeHTML(description));
  }, [description]);

  return (
    <div className="flex flex-col md:flex-row justify-between items-start px-6 md:px-8 py-16 flex-1 max-w-6xl mx-auto gap-10">
      <div className="flex-1 flex flex-col justify-center items-start">
        <p className="text-[16px] text-gray-600 mb-4 tracking-wide">{title}</p>
        <h2 className="text-3xl md:text-[4rem] font-bold text-gray-900 leading-tight">
          {subTitle}
        </h2>
      </div>

      <div
        className={`flex-1 flex flex-col gap-6 text-gray-800 text-base md:text-lg leading-relaxed ${contentClassName || ""}`}
        dangerouslySetInnerHTML={{ __html: desc || "" }}
      />
    </div>
  );
};

export default DescriptionSection;
