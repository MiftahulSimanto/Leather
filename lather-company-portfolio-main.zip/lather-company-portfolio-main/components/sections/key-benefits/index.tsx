import React from "react";
import { FaRocket, FaShieldAlt, FaUsers, FaChartLine } from "react-icons/fa";

type Card = {
  icon: React.ReactNode;
  title: string;
  description: string;
};

const cards: Card[] = [
  { icon: <FaRocket />, title: "1,600+ colors", description: "" },
  {
    icon: <FaShieldAlt />,
    title: "Small and large quantities",
    description: "",
  },
  { icon: <FaUsers />, title: "Items ready in 48 hours", description: "" },
  {
    icon: <FaChartLine />,
    title: "Shipping all over the world",
    description: "",
  },
];

const KeyBenefitsSection = () => {
  return (
    <section className="w-full min-h-screen flex flex-col justify-center items-center bg-gray-50">
      <div className="py-16 px-4 md:px-20 ">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our fast and complete proposal
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover what makes our platform stand out and how it can benefit
            you.
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 justify-items-center px-20">
          {cards.map((card, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-6 flex flex-col items-center justify-center text-center hover:shadow-xl cursor-pointer w-64 h-64"
            >
              {/* Icon */}
              <div className="text-4xl text-gray-600 mb-4 h-[50%] flex items-end justify-center">
                {card.icon}
              </div>
              <div className="flex flex-col   text-center h-[50%]">
                <p className="text-lg  text-gray-900 mb-2">{card.title}</p>
                <p className="text-gray-600">{card.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default KeyBenefitsSection;
