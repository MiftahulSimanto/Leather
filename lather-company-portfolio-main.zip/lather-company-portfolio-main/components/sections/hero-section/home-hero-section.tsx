import React from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, ChevronDown } from "lucide-react";

type IBreadcrumbItem = {
  label: string;
  href?: string;
};

type Props = {
  title: string;
  description: string;
  breadcrumb?: IBreadcrumbItem[];
};

// Minimal Breadcrumb component
const Breadcrumb = ({ items }: { items: IBreadcrumbItem[] }) => {
  return (
    <motion.nav
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center gap-2 text-sm"
    >
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {item.href ? (
            <a
              href={item.href}
              className="text-white/70 hover:text-white transition-colors duration-200"
            >
              {item.label}
            </a>
          ) : (
            <span className="text-white font-medium">{item.label}</span>
          )}
          {index < items.length - 1 && <span className="text-white/50">/</span>}
        </React.Fragment>
      ))}
    </motion.nav>
  );
};

const HeroSection = ({ title, description, breadcrumb }: Props) => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 100]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  const scrollToContent = () => {
    window.scrollTo({
      top: window.innerHeight,
      behavior: "smooth",
    });
  };

  return (
    <div className="relative h-screen overflow-hidden bg-neutral-900">
      {/* Clean Background with Subtle Parallax */}
      <motion.div className="absolute inset-0" style={{ y }}>
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1601758123927-1c3b924f0b6a?auto=format&fit=crop&w=1950&q=80')",
          }}
        />
        {/* Professional overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
      </motion.div>

      {/* Content */}
      <motion.div
        className="relative h-full flex flex-col py-20 md:py-0"
        style={{ opacity }}
      >
        {/* Breadcrumb */}
        {breadcrumb && (
          <div className="absolute top-20 md:top-24 left-0 right-0 w-full max-w-7xl mx-auto px-4 md:px-6 z-20">
            <Breadcrumb items={breadcrumb} />
          </div>
        )}

        {/* Main Content */}
        <div
          className="flex-1 flex flex-col items-center justify-center px-4 md:px-6 z-10 max-w-5xl mx-auto
                      pt-16 md:pt-0"
        >
          {/* Subtitle */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="mb-4 md:mb-6"
          >
            <span
              className="text-xs md:text-sm font-medium text-white/80 uppercase tracking-[0.2em] md:tracking-[0.3em]
                           inline-block px-3 md:px-4 py-1.5 md:py-2 border border-white/20 rounded-sm"
            >
              Premium Leather Goods
            </span>
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl xl:text-8xl font-light text-white text-center
                     mb-4 md:mb-6 lg:mb-8 leading-tight tracking-tight px-4"
          >
            {title}
          </motion.h1>

          {/* Divider */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="w-16 md:w-24 h-px bg-white/40 mb-4 md:mb-6 lg:mb-8"
          />

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="text-base md:text-lg lg:text-xl text-white/80 text-center max-w-2xl
                     mb-8 md:mb-10 lg:mb-12 font-light leading-relaxed px-4"
          >
            {description}
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-3 md:gap-4 w-full sm:w-auto px-4 sm:px-0"
          >
            <motion.button
              whileHover={{ x: 5 }}
              className="group px-6 md:px-6 py-3 md:py-4 bg-white text-black font-medium rounded-sm
                       hover:bg-white/90 transition-all duration-300
                       flex items-center justify-center gap-2 md:gap-3 w-full sm:min-w-[180px] md:min-w-[200px]
                       text-sm md:text-base"
            >
              View Collection
              <ArrowRight className="w-4 h-4 md:w-5 md:h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>

            <motion.button
              whileHover={{ x: 5 }}
              className="group px-6 md:px-8 py-3 md:py-4 bg-transparent text-white font-medium rounded-sm
                       border border-white/40 hover:border-white/70 hover:bg-white/5
                       transition-all duration-300 flex items-center justify-center gap-2 md:gap-3
                       w-full sm:min-w-[180px] md:min-w-[200px] text-sm md:text-base"
            >
              Contact Us
              <ArrowRight className="w-4 h-4 md:w-5 md:h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.8 }}
            className="flex flex-wrap justify-center gap-8 sm:gap-10 md:gap-12 lg:gap-16
                     mt-12 md:mt-16 lg:mt-20 pt-8 md:pt-10 lg:pt-12
                     border-t border-white/10 w-full max-w-4xl mb-16 md:mb-0"
          >
            {[
              { value: "15+", label: "Years of Excellence" },
              { value: "5,000+", label: "Satisfied Clients" },
              { value: "100%", label: "Premium Quality" },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl sm:text-4xl md:text-5xl font-light text-white mb-1 md:mb-2 tracking-tight">
                  {stat.value}
                </div>
                <div className="text-xs md:text-sm text-white/60 uppercase tracking-wider font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Minimal Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute bottom-6 md:bottom-10 lg:bottom-12 left-6 md:left-10 z-30 hidden md:flex"
        >
          <motion.button
            onClick={scrollToContent}
            className="flex flex-col items-start gap-2 md:gap-3 text-white/60 hover:text-white/90
                     transition-colors group cursor-pointer"
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <span className="text-xs uppercase tracking-[0.2em] font-medium">
              Scroll
            </span>
            <ChevronDown className="w-4 h-4 md:w-5 md:h-5" />
          </motion.button>
        </motion.div>
      </motion.div>

      {/* Subtle vignette */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/30 via-transparent to-transparent" />
    </div>
  );
};

export default HeroSection;
