import React from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ChevronRight } from "lucide-react";

type IBreadcrumbItem = {
  label: string;
  href?: string;
};

type Props = {
  title: string;
  description: string;
  breadcrumb?: IBreadcrumbItem[];
};

// Clean Breadcrumb Component
const Breadcrumb = ({ items }: { items: IBreadcrumbItem[] }) => {
  return (
    <motion.nav
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center gap-2 text-sm"
    >
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {item.href ? (
            <a
              href={item.href}
              className="text-white/70 hover:text-white transition-colors duration-200 font-medium"
            >
              {item.label}
            </a>
          ) : (
            <span className="text-white font-medium">{item.label}</span>
          )}
          {index < items.length - 1 && (
            <ChevronRight className="w-4 h-4 text-white/50" />
          )}
        </React.Fragment>
      ))}
    </motion.nav>
  );
};

const HeroSection = ({ title, description, breadcrumb }: Props) => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 300], [0, 50]);

  return (
    <div className="relative h-[60vh] md:h-[70vh] overflow-hidden bg-neutral-900">
      {/* Background with Parallax */}
      <motion.div className="absolute inset-0" style={{ y }}>
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1601758123927-1c3b924f0b6a?auto=format&fit=crop&w=1950&q=80')",
          }}
        />
        {/* Professional overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70" />
      </motion.div>

      {/* Content Container */}
      <div className="relative h-full flex flex-col justify-end md:justify-center px-4 md:px-6 py-12 md:py-0">
        <div className="max-w-7xl mx-auto w-full">
          {/* Breadcrumb */}
          {breadcrumb && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="mb-6 md:mb-8"
            >
              <Breadcrumb items={breadcrumb} />
            </motion.div>
          )}

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-light text-white
                     mb-4 md:mb-6 leading-tight tracking-tight"
          >
            {title}
          </motion.h1>

          {/* Divider */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="w-20 md:w-24 h-px bg-white/40 mb-4 md:mb-6 origin-left"
          />

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="text-base md:text-lg lg:text-xl text-white/80 max-w-2xl
                     font-light leading-relaxed"
          >
            {description}
          </motion.p>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />
    </div>
  );
};

export default HeroSection;
