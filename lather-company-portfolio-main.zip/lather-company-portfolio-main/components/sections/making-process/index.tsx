"use client";
import React from "react";

import { motion } from "framer-motion";

const MakingProcess = () => {
  return (
    <>
      {/* <ContentImageSection
        title="Making Process"
        subTitle="Crafting Quality Leather Goods"
        description="we take pride in offering Full Chrome Cow Crust Leather, a premium-quality leather ideal for crafting high-end shoe uppers. Sourced from Bangladesh, our leather is renowned for its fine grain, durability, and flexibility, making it a top choice for the footwear industry. Whether you’re manufacturing luxury shoes or everyday footwear, our Full Chrome Cow Crust Leather delivers both strength and elegance"
        imageSrc={productProcessingImg}
        position="rightToLeft"
        imageAlt="Leather Experience Making"
        cta={{
          label: "Learn More",
          onClick: () => {
            window.location.href = "/making-process"; // Navigate to the making process page
          },
        }}
      />
      <ContentImageSection
        title="Cow lining crust leather for shoes inner."
        subTitle="Packing and Delivery"
        description="we take pride in offering Full Chrome Cow Crust Leather, a premium-quality leather ideal for crafting high-end shoe uppers. Sourced from Bangladesh, our leather is renowned for its fine grain, durability, and flexibility, making it a top choice for the footwear industry. Whether you’re manufacturing luxury shoes or everyday footwear, our Full Chrome Cow Crust Leather delivers both strength and elegance"
        imageSrc={packingAndDeliveryImg}
        imageAlt="Leather Experience Making"
        cta={{
          label: "Learn More",
          onClick: () => {
            window.location.href = "/making-process"; // Navigate to the making process page
          },
        }}
      />
      <ContentImageSection
        title="Making Process"
        subTitle="Crafting Quality Leather Goods"
        description="we take pride in offering Full Chrome Cow Crust Leather, a premium-quality leather ideal for crafting high-end shoe uppers. Sourced from Bangladesh, our leather is renowned for its fine grain, durability, and flexibility, making it a top choice for the footwear industry. Whether you’re manufacturing luxury shoes or everyday footwear, our Full Chrome Cow Crust Leather delivers both strength and elegance"
        imageSrc={leatherExperienceMaking}
        position="rightToLeft"
        imageAlt="Leather Experience Making"
        cta={{
          label: "Learn More",
          onClick: () => {
            window.location.href = "/making-process"; // Navigate to the making process page
          },
        }}
      />
      <ContentImageSection
        title="Cow lining crust leather for shoes inner."
        subTitle="Packing and Delivery"
        description="we take pride in offering Full Chrome Cow Crust Leather, a premium-quality leather ideal for crafting high-end shoe uppers. Sourced from Bangladesh, our leather is renowned for its fine grain, durability, and flexibility, making it a top choice for the footwear industry. Whether you’re manufacturing luxury shoes or everyday footwear, our Full Chrome Cow Crust Leather delivers both strength and elegance"
        imageSrc={packingAndDeliveryImg}
        imageAlt="Leather Experience Making"
        cta={{
          label: "Learn More",
          onClick: () => {
            window.location.href = "/making-process"; // Navigate to the making process page
          },
        }}
      /> */}
      <section className="w-full bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16 md:mb-24">
            <span className="text-xl font-bold text-amber-600 tracking-widest uppercase">
              Leather Finishes & Categories
            </span>
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-light text-gray-900 mt-3">
              Articles
            </h2>
          </div>

          {/* Block 1: Full Grain Leather */}
          <div className="flex flex-col lg:flex-row items-start gap-12 lg:gap-20 mb-24 lg:mb-32">
            {/* Content Side */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="flex-1"
            >
              <h3 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                A. Full Grain Leather
              </h3>
              <p className="text-2xl text-gray-600 mb-6 leading-relaxed">
                The most premium grade — made from the top layer of the hide
                without removing natural grain.
              </p>

              {/* Features & Best For */}
              <div className="bg-amber-50/50 rounded-xl p-6 mb-8 border border-amber-100">
                <h4 className="text-2xl font-bold text-amber-800 uppercase tracking-wider mb-3">
                  Features
                </h4>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-gray-700 text-xl">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    Highest strength
                  </li>
                  <li className="flex items-center gap-2 text-gray-700 text-xl">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    Natural beauty and unique markings
                  </li>
                  <li className="flex items-center gap-2 text-gray-700 text-xl">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    Develops a rich patina with age
                  </li>
                </ul>
                <div className="pt-4 border-t border-amber-200">
                  <span className="text-xl font-bold text-amber-800 uppercase tracking-wider">
                    Best For:
                  </span>{" "}
                  <span className="text-gray-700 text-xl">
                    Luxury goods, heritage products, premium collections.
                  </span>
                </div>
              </div>

              {/* Full Grain Categories */}
              <div className="space-y-8">
                <div>
                  <h4 className="text-3xl font-semibold text-gray-900 mb-3">
                    Full Grain Categories
                  </h4>
                  <div className="space-y-6">
                    {/* Wet Blue */}
                    <div>
                      <h5 className="font-bold text-gray-800 mb-1 text-2xl">
                        Wet Blue
                      </h5>
                      <p className="text-xl text-gray-600 mb-2">
                        Completed chrome-tanning stage, retaining full natural
                        grain.
                      </p>
                      <p className="text-xl text-gray-500">
                        <span className="font-medium">Use:</span> Luxury
                        finished leather, high-quality footwear, premium bags.
                      </p>
                    </div>

                    {/* Crust Leather */}
                    <div>
                      <h5 className="font-bold text-gray-800 mb-1 text-2xl">
                        Crust Leather
                      </h5>
                      <p className="text-xl text-gray-600 mb-2">
                        Tanned but not yet finished — perfect for custom colors.
                      </p>
                      <p className="text-xl text-gray-500">
                        <span className="font-medium">Use:</span> Custom dyeing,
                        bespoke projects.
                      </p>
                    </div>

                    {/* Lining Leather */}
                    <div>
                      <h5 className="font-bold text-gray-800 mb-1 text-2xl">
                        Lining Leather
                      </h5>
                      <p className="text-xl text-gray-600 mb-2">
                        Soft, light, and smooth leather used inside products.
                      </p>
                      <p className="text-xl text-gray-500">
                        <span className="font-medium">Use:</span> Bag interiors,
                        shoe linings, wallets.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Finished Leather Grid */}
                <div>
                  <h4 className="text-3xl font-semibold text-gray-900 mb-4">
                    Finished Leather Types
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {[
                      {
                        name: "Aniline",
                        desc: "Pure, transparent finish highlighting natural grain.",
                        use: "High-end bags, jackets",
                      },
                      {
                        name: "Semi-Aniline",
                        desc: "Protective topcoat retaining natural look.",
                        use: "Premium accessories",
                      },
                      {
                        name: "Pigment Finished",
                        desc: "Uniform color and higher resistance.",
                        use: "Footwear, everyday bags",
                      },
                      {
                        name: "Oil Pull-Up",
                        desc: "Infused with oils for vintage effect.",
                        use: "Travel bags, boots",
                      },
                      {
                        name: "Crazy Horse",
                        desc: "Rugged, heritage look with pull-up.",
                        use: "Outdoor bags, vintage style",
                      },
                      {
                        name: "Antique Finish",
                        desc: "Multi-tone shading for handcrafted look.",
                        use: "Classic bags, retro accessories",
                      },
                      {
                        name: "Embossed Leather",
                        desc: "Pressed with patterns (crocodile, pebble, etc.)",
                        use: "Fashion bags, wallets",
                      },
                      {
                        name: "Patent Leather",
                        desc: "Glossy, mirror-like finish.",
                        use: "Formal accessories, shoes",
                      },
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        className="bg-gray-50 p-4 rounded-lg border border-gray-100"
                      >
                        <h6 className="font-bold text-gray-900 text-2xl mb-1">
                          {item.name}
                        </h6>
                        <p className="text-xl text-gray-600 mb-1 leading-snug">
                          {item.desc}
                        </p>
                        <p className="text-xl text-gray-500">
                          <span className="font-medium">Use:</span> {item.use}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Image Side */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="flex-1 w-full lg:sticky lg:top-32 lg:h-[calc(100vh-160px)] min-h-[400px] bg-gray-200 rounded-2xl overflow-hidden relative"
            >
              {/* Placeholder for Image */}
              <div className="absolute inset-0 flex items-center justify-center text-gray-400 bg-gray-100">
                <span className="text-2xl font-medium">
                  Full Grain Leather Image Placeholder
                </span>
              </div>
            </motion.div>
          </div>

          {/* Block 2: Split Leather */}
          <div className="flex flex-col lg:flex-row-reverse items-start gap-12 lg:gap-20">
            {/* Content Side */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="flex-1"
            >
              <h3 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                B. Split Leather
              </h3>
              <p className="text-2xl text-gray-600 mb-6 leading-relaxed">
                Derived from the lower layer of the hide, offering versatility
                and cost-effectiveness.
              </p>

              <div className="space-y-8">
                {/* Wet Blue Split */}
                <div className="bg-blue-50/50 rounded-xl p-6 border border-blue-100">
                  <h4 className="text-2xl font-bold text-blue-900 mb-2">
                    Wet Blue Split
                  </h4>
                  <p className="text-xl text-gray-700 mb-4 leading-relaxed">
                    Chrome-tanned lower layer, not yet colored. Forms the base
                    for suede and lining.
                  </p>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-xl text-gray-600">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      Stable & Consistent Structure
                    </div>
                    <div className="flex items-center gap-2 text-xl text-gray-600">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      Versatile for Conversion
                    </div>
                    <div className="flex items-center gap-2 text-xl text-gray-600">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      Cost-Effective
                    </div>
                  </div>
                  <p className="text-xl text-gray-500">
                    <span className="font-medium text-blue-800">Use:</span>{" "}
                    Suede, gloves, industrial goods, budget lines.
                  </p>
                </div>

                {/* Suede */}
                <div>
                  <h4 className="text-3xl font-semibold text-gray-900 mb-3">
                    Suede
                  </h4>
                  <p className="text-xl text-gray-600 mb-3">
                    Soft, velvety surface created from the flesh side of split
                    leather.
                  </p>
                  <ul className="space-y-1 mb-3">
                    <li className="flex items-center gap-2 text-xl text-gray-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
                      Luxurious texture
                    </li>
                    <li className="flex items-center gap-2 text-xl text-gray-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
                      Lightweight & Fashion-forward
                    </li>
                  </ul>
                  <p className="text-xl text-gray-500">
                    <span className="font-medium">Best For:</span> Shoes,
                    handbags, apparel.
                  </p>
                </div>

                {/* Nubuck Leather */}
                <div className="pt-6 border-t border-gray-100">
                  <h4 className="text-3xl font-semibold text-gray-900 mb-3">
                    Nubuck Leather
                  </h4>
                  <p className="text-xl text-gray-600 mb-3">
                    Made from top grain and lightly sanded to achieve a
                    velvet-like surface.
                  </p>
                  <ul className="space-y-1 mb-3">
                    <li className="flex items-center gap-2 text-xl text-gray-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
                      Stronger than suede
                    </li>
                    <li className="flex items-center gap-2 text-xl text-gray-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
                      Premium matte texture
                    </li>
                  </ul>
                  <p className="text-xl text-gray-500">
                    <span className="font-medium">Best For:</span> Jackets,
                    boots, premium accessories.
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Image Side */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="flex-1 w-full h-full min-h-[400px] lg:min-h-[800px] bg-gray-200 rounded-2xl overflow-hidden relative"
            >
              {/* Placeholder for Image */}
              <div className="absolute inset-0 flex items-center justify-center text-gray-400 bg-gray-100">
                <span className="text-2xl font-medium">
                  Split Leather Image Placeholder
                </span>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default MakingProcess;
