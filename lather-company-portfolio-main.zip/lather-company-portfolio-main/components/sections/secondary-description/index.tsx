import React from "react";
import { motion } from "framer-motion";

type Props = {
  subTitle?: string;
  title?: string;
  description?: string;
};

const SecondaryDescriptionSection = ({
  subTitle,
  title,
  description,
}: Props) => {
  return (
    <section className="w-full bg-[#f4f0ed] py-16 md:py-24 lg:py-32">
      <div className="max-w-5xl mx-auto px-6 md:px-10 lg:px-12">
        {/* Subtitle */}
        {subTitle && (
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-xs md:text-sm font-medium text-gray-600 uppercase
                     tracking-[0.2em] mb-6 block text-center"
          >
            {subTitle}
          </motion.span>
        )}

        {/* Title */}
        {title && (
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-light text-gray-900
                     mb-8 md:mb-12 text-center tracking-tight leading-tight max-w-4xl mx-auto"
          >
            {title}
          </motion.h2>
        )}

        {/* Divider */}
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="w-20 h-px bg-gray-800 mb-12 md:mb-16 mx-auto"
        />

        {/* Description */}
        {description && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="prose prose-gray prose-lg md:prose-xl mx-auto text-center
                     prose-p:text-black prose-p:leading-relaxed prose-p:mb-6
                     prose-headings:font-light prose-headings:text-black
                     prose-strong:text-black prose-strong:font-medium text-gray-600 flex flex-col gap-5
                     max-w-3xl"
            dangerouslySetInnerHTML={{ __html: description }}
          />
        )}
      </div>
    </section>
  );
};

export default SecondaryDescriptionSection;
