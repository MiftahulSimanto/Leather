"use client";
import React from "react";

const AboutProductSection = () => {
  return (
    <section className="w-full flex flex-col bg-gradient-to-b from-[#f5f2ef] to-[#e8e4e1] px-4 sm:px-6 md:px-20">
      {/* Intro Section */}
      <div className="flex flex-col justify-center items-center px-4 sm:px-6 py-12 md:py-16 ">
        {/* Section Subtitle */}
        <p className="text-sm sm:text-base text-gray-500 tracking-wide text-center mb-2 uppercase">
          The art of our products
        </p>

        {/* Section Title */}
        <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-[3.5rem] font-extrabold text-gray-900 mb-12 text-center leading-snug">
          Explore Product Types
        </h2>

        {/* Leather Cards Container */}
        <div className="w-full max-w-7xl">
          {/* Horizontal scroll on mobile, 4-column grid on larger screens */}
          <div className="flex space-x-5 overflow-x-auto snap-x snap-mandatory pb-4 sm:grid sm:grid-cols-2 lg:grid-cols-4 sm:gap-6 sm:space-x-0 sm:pb-0">
            {/* Cow Leather */}
            <div className="group relative flex-shrink-0 snap-start bg-white rounded-xl overflow-hidden min-w-[280px] sm:min-w-0 border border-gray-100 hover:border-amber-200 transition-all duration-500 hover:shadow-[0_20px_50px_rgba(180,160,140,0.15)]">
              {/* Top Accent Bar */}
              <div className="h-1.5 w-full bg-gradient-to-r from-amber-600 via-amber-500 to-amber-400"></div>

              {/* Card Content */}
              <div className="p-6">
                {/* Icon Badge */}
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-50 to-amber-100 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                  <span className="text-2xl">🐄</span>
                </div>

                <h3 className="text-xl font-semibold text-gray-900 mb-2 tracking-tight">
                  Cow Leather
                </h3>
                <p className="text-sm text-gray-500 mb-5 leading-relaxed">
                  The industry standard for premium leather goods — strong,
                  soft, and versatile.
                </p>

                {/* Features */}
                <div className="space-y-2.5 mb-5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-500"></div>
                    <span className="text-sm text-gray-600">
                      Durable yet flexible
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-500"></div>
                    <span className="text-sm text-gray-600">
                      Smooth, consistent grain
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-500"></div>
                    <span className="text-sm text-gray-600">
                      Excellent for finishing
                    </span>
                  </div>
                </div>

                {/* Best For Tag */}
                <div className="pt-4 border-t border-gray-100">
                  <p className="text-xs uppercase tracking-wider text-amber-700 font-medium mb-1">
                    Best For
                  </p>
                  <p className="text-sm text-gray-700">
                    Jackets, luxury bags, footwear
                  </p>
                </div>
              </div>
            </div>

            {/* Goat Leather */}
            <div className="group relative flex-shrink-0 snap-start bg-white rounded-xl overflow-hidden min-w-[280px] sm:min-w-0 border border-gray-100 hover:border-stone-300 transition-all duration-500 hover:shadow-[0_20px_50px_rgba(180,160,140,0.15)]">
              {/* Top Accent Bar */}
              <div className="h-1.5 w-full bg-gradient-to-r from-stone-600 via-stone-500 to-stone-400"></div>

              {/* Card Content */}
              <div className="p-6">
                {/* Icon Badge */}
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-stone-50 to-stone-100 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                  <span className="text-2xl">🐐</span>
                </div>

                <h3 className="text-xl font-semibold text-gray-900 mb-2 tracking-tight">
                  Goat Leather
                </h3>
                <p className="text-sm text-gray-500 mb-5 leading-relaxed">
                  Naturally soft, lightweight, with a distinctive fine grain.
                </p>

                {/* Features */}
                <div className="space-y-2.5 mb-5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-stone-500"></div>
                    <span className="text-sm text-gray-600">
                      Soft and supple
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-stone-500"></div>
                    <span className="text-sm text-gray-600">
                      Fine natural grain
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-stone-500"></div>
                    <span className="text-sm text-gray-600">
                      Lightweight but durable
                    </span>
                  </div>
                </div>

                {/* Best For Tag */}
                <div className="pt-4 border-t border-gray-100">
                  <p className="text-xs uppercase tracking-wider text-stone-600 font-medium mb-1">
                    Best For
                  </p>
                  <p className="text-sm text-gray-700">
                    Wallets, linings, accessories
                  </p>
                </div>
              </div>
            </div>

            {/* Buffalo Leather */}
            <div className="group relative flex-shrink-0 snap-start bg-white rounded-xl overflow-hidden min-w-[280px] sm:min-w-0 border border-gray-100 hover:border-zinc-300 transition-all duration-500 hover:shadow-[0_20px_50px_rgba(180,160,140,0.15)]">
              {/* Top Accent Bar */}
              <div className="h-1.5 w-full bg-gradient-to-r from-zinc-700 via-zinc-600 to-zinc-500"></div>

              {/* Card Content */}
              <div className="p-6">
                {/* Icon Badge */}
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-zinc-50 to-zinc-100 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                  <span className="text-2xl">🐃</span>
                </div>

                <h3 className="text-xl font-semibold text-gray-900 mb-2 tracking-tight">
                  Buffalo Leather
                </h3>
                <p className="text-sm text-gray-500 mb-5 leading-relaxed">
                  Thick, textured, and extremely tough — perfect for heavy-duty
                  products.
                </p>

                {/* Features */}
                <div className="space-y-2.5 mb-5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-zinc-500"></div>
                    <span className="text-sm text-gray-600">
                      Strong and rugged
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-zinc-500"></div>
                    <span className="text-sm text-gray-600">
                      Bold grain patterns
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-zinc-500"></div>
                    <span className="text-sm text-gray-600">
                      Heavy-duty excellence
                    </span>
                  </div>
                </div>

                {/* Best For Tag */}
                <div className="pt-4 border-t border-gray-100">
                  <p className="text-xs uppercase tracking-wider text-zinc-600 font-medium mb-1">
                    Best For
                  </p>
                  <p className="text-sm text-gray-700">
                    Belts, travel bags, work boots
                  </p>
                </div>
              </div>
            </div>

            {/* Sheep Leather */}
            <div className="group relative flex-shrink-0 snap-start bg-white rounded-xl overflow-hidden min-w-[280px] sm:min-w-0 border border-gray-100 hover:border-rose-200 transition-all duration-500 hover:shadow-[0_20px_50px_rgba(180,160,140,0.15)]">
              {/* Top Accent Bar */}
              <div className="h-1.5 w-full bg-gradient-to-r from-rose-400 via-rose-300 to-pink-300"></div>

              {/* Card Content */}
              <div className="p-6">
                {/* Icon Badge */}
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-rose-50 to-pink-50 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                  <span className="text-2xl">🐑</span>
                </div>

                <h3 className="text-xl font-semibold text-gray-900 mb-2 tracking-tight">
                  Sheep Leather
                </h3>
                <p className="text-sm text-gray-500 mb-5 leading-relaxed">
                  Ultra-soft, smooth, and luxurious with a buttery feel.
                </p>

                {/* Features */}
                <div className="space-y-2.5 mb-5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-rose-400"></div>
                    <span className="text-sm text-gray-600">
                      Ultra-soft texture
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-rose-400"></div>
                    <span className="text-sm text-gray-600">
                      Lightweight and flexible
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-rose-400"></div>
                    <span className="text-sm text-gray-600">
                      Premium comfort
                    </span>
                  </div>
                </div>

                {/* Best For Tag */}
                <div className="pt-4 border-t border-gray-100">
                  <p className="text-xs uppercase tracking-wider text-rose-500 font-medium mb-1">
                    Best For
                  </p>
                  <p className="text-sm text-gray-700">
                    Premium jackets, gloves, fashion
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Types of Tanning Section */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-20">
        <div className="text-center mb-12">
          <span className="text-sm font-bold text-amber-600 tracking-widest uppercase">
            Process & Technique
          </span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mt-3 mb-4">
            Types of Tanning
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-base leading-relaxed">
            We utilize a variety of tanning methods to achieve the perfect
            balance of durability, feel, and environmental responsibility.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Full Chrome Tanning */}
          <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100 hover:border-blue-300 transition-all duration-300 hover:shadow-md">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                Full Chrome Tanning
              </h3>
              <span className="text-2xl">🟦</span>
            </div>
            <p className="text-sm text-gray-700 mb-4 leading-relaxed min-h-[40px]">
              Chrome-tanned leather is soft, flexible, and vibrant in color.
            </p>
            <div className="space-y-2 mb-5">
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                Excellent color uniformity
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                Water-resistant
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                Ideal for modern fashion
              </div>
            </div>
            <div className="pt-4 border-t border-blue-200">
              <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block mb-1">
                Best For
              </span>
              <span className="text-xs text-gray-700">
                Trendy bags, premium footwear, colorful articles
              </span>
            </div>
          </div>

          {/* Semi Chrome Tanning */}
          <div className="bg-emerald-50 rounded-2xl p-6 border border-emerald-100 hover:border-emerald-300 transition-all duration-300 hover:shadow-md">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                Semi Chrome Tanning
              </h3>
              <span className="text-2xl">🟩</span>
            </div>
            <p className="text-sm text-gray-700 mb-4 leading-relaxed min-h-[40px]">
              A balanced process that combines chrome with vegetable tanning.
            </p>
            <div className="space-y-2 mb-5">
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                Softness of chrome + body of veg
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                Better fiber structure
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                Improved durability
              </div>
            </div>
            <div className="pt-4 border-t border-emerald-200">
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block mb-1">
                Best For
              </span>
              <span className="text-xs text-gray-700">
                Bags, structured accessories, premium small goods
              </span>
            </div>
          </div>

          {/* Full Vegetable Tanning */}
          <div className="bg-amber-50 rounded-2xl p-6 border border-amber-100 hover:border-amber-300 transition-all duration-300 hover:shadow-md">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                Full Vegetable Tanning
              </h3>
              <span className="text-2xl">🟫</span>
            </div>
            <p className="text-sm text-gray-700 mb-4 leading-relaxed min-h-[40px]">
              A traditional, eco-conscious process using natural plant extracts.
            </p>
            <div className="space-y-2 mb-5">
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                Rich, earthy tones
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                Ages beautifully with patina
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                Strong, long-lasting structure
              </div>
            </div>
            <div className="pt-4 border-t border-amber-200">
              <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block mb-1">
                Best For
              </span>
              <span className="text-xs text-gray-700">
                Belts, handcrafted goods, artisan leather products
              </span>
            </div>
          </div>

          {/* Semi Vegetable Tanning */}
          <div className="bg-orange-50 rounded-2xl p-6 border border-orange-100 hover:border-orange-300 transition-all duration-300 hover:shadow-md">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                Semi Vegetable Tanning
              </h3>
              <span className="text-2xl">🟧</span>
            </div>
            <p className="text-sm text-gray-700 mb-4 leading-relaxed min-h-[40px]">
              Hybrid method preserving natural feel but softer and easier to
              use.
            </p>
            <div className="space-y-2 mb-5">
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                Smoother handling
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                Retains natural character
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                Good shape retention
              </div>
            </div>
            <div className="pt-4 border-t border-orange-200">
              <span className="text-[10px] font-bold text-orange-700 uppercase tracking-wider block mb-1">
                Best For
              </span>
              <span className="text-xs text-gray-700">
                Luxury bags, small leather goods, accessories
              </span>
            </div>
          </div>

          {/* Chrome-Free Tanning */}
          <div className="bg-lime-50 rounded-2xl p-6 border border-lime-100 hover:border-lime-300 transition-all duration-300 hover:shadow-md">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                Chrome-Free Tanning
              </h3>
              <span className="text-2xl">🌱</span>
            </div>
            <p className="text-sm text-gray-700 mb-4 leading-relaxed min-h-[40px]">
              A clean tanning method with zero chromium content.
            </p>
            <div className="space-y-2 mb-5">
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-lime-600"></span>
                Hypoallergenic
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-lime-600"></span>
                Eco-friendlier process
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-lime-600"></span>
                Natural, soft feel
              </div>
            </div>
            <div className="pt-4 border-t border-lime-200">
              <span className="text-[10px] font-bold text-lime-700 uppercase tracking-wider block mb-1">
                Best For
              </span>
              <span className="text-xs text-gray-700">
                Sustainable product lines, children’s shoes
              </span>
            </div>
          </div>

          {/* Chrome-Free Full Veg Character */}
          <div className="bg-green-50 rounded-2xl p-6 border border-green-100 hover:border-green-300 transition-all duration-300 hover:shadow-md">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                Chrome-Free Veg Character
              </h3>
              <span className="text-2xl">🌿</span>
            </div>
            <p className="text-sm text-gray-700 mb-4 leading-relaxed min-h-[40px]">
              Premium eco-leather with vegetable character, free from chromium.
            </p>
            <div className="space-y-2 mb-5">
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-green-600"></span>
                Rich natural grain
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-green-600"></span>
                Organic appearance
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-green-600"></span>
                High-end sustainable goods
              </div>
            </div>
            <div className="pt-4 border-t border-green-200">
              <span className="text-[10px] font-bold text-green-700 uppercase tracking-wider block mb-1">
                Best For
              </span>
              <span className="text-xs text-gray-700">
                Luxury accessories, designer collections
              </span>
            </div>
          </div>

          {/* Chrome-Free Ecological Tanning */}
          <div className="bg-teal-50 rounded-2xl p-6 border border-teal-100 hover:border-teal-300 transition-all duration-300 hover:shadow-md md:col-span-2 lg:col-span-1 lg:col-start-2">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                Chrome-Free Ecological
              </h3>
              <span className="text-2xl">♻️</span>
            </div>
            <p className="text-sm text-gray-700 mb-4 leading-relaxed min-h-[40px]">
              Advanced, environmentally-responsible tanning with minimal
              chemicals.
            </p>
            <div className="space-y-2 mb-5">
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600"></span>
                Low environmental impact
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600"></span>
                Soft, natural texture
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600"></span>
                Global eco-standards
              </div>
            </div>
            <div className="pt-4 border-t border-teal-200">
              <span className="text-[10px] font-bold text-teal-700 uppercase tracking-wider block mb-1">
                Best For
              </span>
              <span className="text-xs text-gray-700">
                European markets, sustainability-focused brands
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Statistics Section */}
      <div className="w-full py-10 sm:py-12 md:py-16 flex justify-center bg-gradient-to-r from-[#ffffff] via-[#f9f7f3] to-[#ffffff] shadow-lg rounded-t-xl">
        <div className="max-w-6xl w-full flex flex-col sm:flex-col md:flex-row items-center justify-center gap-6 md:gap-12 text-center px-4 sm:px-6">
          {/* Tab 1 */}
          <div className="flex-1 px-2 sm:px-4 py-4  rounded-lg  transition-shadow duration-300">
            <h3 className="text-2xl sm:text-3xl md:text-5xl lg:text-[4.375rem] font-bold text-gray-900 mb-1 sm:mb-2 md:mb-4">
              65+
            </h3>
            <p className="text-[10px] sm:text-xs md:text-sm lg:text-base text-gray-600 uppercase tracking-widest">
              Years of Experience
            </p>
          </div>

          {/* Divider */}
          <div className="hidden md:block w-px h-24 md:h-32 border-r-2 border-dotted border-gray-300"></div>

          {/* Tab 2 */}
          <div className="flex-1 px-2 sm:px-4 py-4  rounded-lg  transition-shadow duration-300">
            <h3 className="text-2xl sm:text-3xl md:text-5xl lg:text-[4.375rem] font-bold text-gray-900 mb-1 sm:mb-2 md:mb-4">
              3
            </h3>
            <p className="text-[10px] sm:text-xs md:text-sm lg:text-base text-gray-600 uppercase tracking-widest">
              Business Units: Fashion, Interior Design, Automotive
            </p>
          </div>

          {/* Divider */}
          <div className="hidden md:block w-px h-24 md:h-32 border-r-2 border-dotted border-gray-300"></div>

          {/* Tab 3 */}
          <div className="flex-1 px-2 sm:px-4 py-4  rounded-lg  transition-shadow duration-300">
            <h3 className="text-2xl sm:text-3xl md:text-5xl lg:text-[4.375rem] font-bold text-gray-900 mb-1 sm:mb-2 md:mb-4">
              ∞
            </h3>
            <p className="text-[10px] sm:text-xs md:text-sm lg:text-base text-gray-600 uppercase tracking-widest">
              Possibilities of Use
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutProductSection;
