"use client";

import React, { useRef, useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/grid";
import { Autoplay, Navigation, Pagination, Grid } from "swiper/modules";
import { FaArrowLeft, FaArrowRight, FaRegUser } from "react-icons/fa";

const reviews = [
  {
    name: "John Doe",
    role: "CEO, Company A",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
  {
    name: "John Doe",
    role: "CEO, Company A",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
  {
    name: "Jane Smith",
    role: "Marketing Manager, Company B",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
  {
    name: "Jane Smith",
    role: "Marketing Manager, Company B",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
  {
    name: "Jane Smith",
    role: "Marketing Manager, Company B",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
  {
    name: "Michael Johnson",
    role: "Designer, Company C",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
  {
    name: "Alice Brown",
    role: "Developer, Company D",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
  {
    name: "David Lee",
    role: "Consultant, Company E",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
  {
    name: "Emma Wilson",
    role: "Manager, Company F",
    review:
      "Absolutely loved the experience. Highly recommended! Since they are the only one sourcing agent for me…",
  },
];

const ClientReview = () => {
  const prevRef = useRef<HTMLDivElement>(null);
  const nextRef = useRef<HTMLDivElement>(null);
  const [swiperReady, setSwiperReady] = useState(false);

  useEffect(() => {
    setSwiperReady(true);
  }, []);

  return (
    <section className="py-20 bg-gray-50 text-gray-800">
      <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
        What Our Clients Say
      </h2>
      <div className="max-w-6xl mx-auto px-6 relative">
        {/* Navigation Buttons */}
        <div
          ref={prevRef}
          className="absolute left-[-2%] top-1/2 -translate-y-1/2 z-10 cursor-pointer p-3 bg-white rounded-full shadow-lg hidden md:flex"
        >
          <FaArrowLeft />
        </div>
        <div
          ref={nextRef}
          className="absolute right-[-2%] top-1/2 -translate-y-1/2 z-10 cursor-pointer p-3 bg-white rounded-full shadow-lg hidden md:flex"
        >
          <FaArrowRight />
        </div>

        {swiperReady && (
          <Swiper
            modules={[Navigation, Pagination, Autoplay, Grid]}
            spaceBetween={20}
            slidesPerView={1}
            grid={{ rows: 2, fill: "row" }}
            navigation={{ prevEl: prevRef.current, nextEl: nextRef.current }}
            pagination={{
              clickable: true,
              el: ".swiper-pagination-custom",
              bulletClass:
                "swiper-pagination-bullet !w-4 !h-4 !bg-gray-300 !mx-1 rounded-full",
              bulletActiveClass: "!bg-gray-800",
            }}
            autoplay={{ delay: 5000 }}
            loop
            breakpoints={{
              0: { slidesPerView: 1, grid: { rows: 2 } },
              640: { slidesPerView: 1, grid: { rows: 2 } },
              768: { slidesPerView: 2, grid: { rows: 2 } },
              1024: { slidesPerView: 3, grid: { rows: 2 } },
              1280: { slidesPerView: 3, grid: { rows: 2 } },
            }}
            className="relative"
          >
            {reviews.map((review, index) => (
              <SwiperSlide key={index} className="flex justify-center">
                <div className="bg-white rounded-2xl shadow-lg p-6 flex flex-col items-center text-center justify-between w-full max-w-sm min-h-[280px]">
                  <FaRegUser className="w-16 h-16 mb-4 text-gray-400" />
                  <p className="text-gray-700 mb-4 flex-1">{review.review}</p>
                  <h3 className="text-lg font-semibold">{review.name}</h3>
                  <span className="text-sm text-gray-500">{review.role}</span>
                </div>
              </SwiperSlide>
            ))}

            {/* Custom pagination container */}
            <div className="swiper-pagination-custom absolute bottom-4 left-0 right-0 flex justify-center"></div>
          </Swiper>
        )}
      </div>
    </section>
  );
};

export default ClientReview;
