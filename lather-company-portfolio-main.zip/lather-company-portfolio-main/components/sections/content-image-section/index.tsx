"use client";

import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { StaticImageData } from "next/image";

type Props = {
  title: string;
  subTitle: string;
  description: string; // Can contain HTML
  imageSrc: string | StaticImageData;
  imageAlt: string;
  position?: "leftToRight" | "rightToLeft";
  cta?: {
    label: string;
    onClick?: () => void;
  };
};

const sanitizeHTML = (html: string) => html;

const ContentImageSection = ({
  title,
  subTitle,
  description,
  imageSrc,
  imageAlt,
  cta,
  position = "leftToRight",
}: Props) => {
  const [desc, setDesc] = useState<string>();

  useEffect(() => {
    setDesc(sanitizeHTML(description));
  }, [description]);

  const isReversed = position === "rightToLeft";

  return (
    <section className="w-full bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`flex flex-col ${
            isReversed ? "lg:flex-row-reverse" : "lg:flex-row"
          } items-center justify-center gap-10 lg:gap-20 py-12 sm:py-16 lg:py-24`}
        >
          {/* ===== Content Side ===== */}
          <motion.div
            initial={{ opacity: 0, x: isReversed ? 60 : -60 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="flex-1 flex flex-col justify-center text-center lg:text-left max-w-2xl"
          >
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-xs sm:text-sm font-medium text-neutral-500 uppercase tracking-[0.2em] mb-3 sm:mb-4"
            >
              {subTitle}
            </motion.span>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-light text-neutral-900 leading-tight mb-4 sm:mb-6"
            >
              {title}
            </motion.h2>

            <motion.div
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="w-12 sm:w-16 h-px bg-neutral-900 mx-auto lg:mx-0 mb-4 sm:mb-6 origin-left"
            />

            {desc && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="text-sm sm:text-base md:text-lg text-neutral-600 leading-relaxed mb-6 sm:mb-8 prose prose-neutral mx-auto lg:mx-0"
                dangerouslySetInnerHTML={{ __html: desc }}
              />
            )}

            {cta && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <motion.button
                  onClick={cta.onClick}
                  whileHover={{ x: 5 }}
                  className="group inline-flex items-center gap-2 sm:gap-3 px-6 sm:px-8 py-3 sm:py-4 bg-neutral-900 text-white font-medium rounded-md hover:bg-neutral-800 transition-all duration-300 text-sm sm:text-base"
                >
                  {cta.label}
                  <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 transition-transform duration-300 group-hover:translate-x-1" />
                </motion.button>
              </motion.div>
            )}
          </motion.div>

          {/* ===== Image Side ===== */}
          <motion.div
            initial={{ opacity: 0, x: isReversed ? -60 : 60 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="flex-1 w-full max-w-xl sm:max-w-2xl lg:max-w-none relative overflow-hidden rounded-lg shadow-md"
          >
            <div
              className="aspect-[1/1] lg:aspect-[5/6] bg-cover bg-center hover:scale-105 transition-transform duration-700"
              style={{ backgroundImage: `url(${imageSrc})` }}
              role="img"
              aria-label={imageAlt}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent lg:hidden" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ContentImageSection;
