"use client";

import React from "react";

const MasterLeatherCraftsman = () => {
  return (
    <section className="flex flex-col justify-center items-start px-6 md:px-16 lg:px-32 py-20 min-h-screen w-full bg-gradient-to-b from-[#f5f2ef] to-[#e8e4e1]">
      <div className="max-w-5xl w-full flex flex-col gap-6 md:gap-10">
        {/* Subtitle */}
        <p className="text-sm md:text-base text-gray-500 uppercase tracking-wider">
          Leather under our skin
        </p>

        {/* Main Heading */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold text-gray-900 leading-snug md:leading-tight">
          Guided by the passion for leather, we offer our clients quality,
          innovative, and durable solutions.
        </h1>

        {/* Description */}
        <p className="text-gray-700 text-base md:text-lg leading-relaxed md:leading-loose max-w-3xl">
          In a constantly evolving world, we firmly believe in having a clear
          and meaningful purpose that guides the company&apos;s strategy,
          inspiring our team and communities.
        </p>

        {/* CTA Button */}
        <div className="mt-6 md:mt-10">
          <a
            href="#contact"
            className="inline-block px-8 py-4 bg-gray-900 text-white rounded-xl font-semibold text-base md:text-lg hover:bg-gray-800 transition duration-300 shadow-lg hover:shadow-xl"
          >
            Purpose and values
          </a>
        </div>
      </div>
    </section>
  );
};

export default MasterLeatherCraftsman;
