import React from "react";
import Image from "next/image";
import {
  automotiveCatImg,
  aviationCatImg,
  leatherGroupImg,
  nauticalCatImg,
} from "@/assets";

export default function LuxuryLeatherShowcase() {
  const leatherImages = [
    {
      src: leatherGroupImg,
      alt: "Dark Brown Leather",
      position:
        "-translate-x-[80px] -translate-y-[80px] sm:-translate-x-[120px] sm:-translate-y-[100px] md:-translate-x-[170px] lg:-translate-x-[200px] md:-translate-y-[120px] lg:-translate-y-[130px] -rotate-[15deg] z-30",
    },
    {
      src: automotiveCatImg,
      alt: "Tan Leather",
      position:
        "-translate-x-[40px] -translate-y-[90px] sm:-translate-x-[60px] sm:-translate-y-[110px] md:-translate-x-[90px] lg:-translate-x-[100px] md:-translate-y-[130px] lg:-translate-y-[140px] -rotate-[8deg] z-40",
    },
    {
      src: nauticalCatImg,
      alt: "Medium Brown Leather",
      position:
        "translate-x-[5px] -translate-y-[85px] sm:translate-x-[10px] sm:-translate-y-[105px] md:translate-x-[10px] lg:translate-x-[20px] md:-translate-y-[125px] lg:-translate-y-[135px] rotate-[5deg] z-50",
    },
    {
      src: aviationCatImg,
      alt: "Very Dark Brown Leather",
      position:
        "translate-x-[45px] -translate-y-[75px] sm:translate-x-[70px] sm:-translate-y-[95px] md:translate-x-[90px] lg:translate-x-[120px] md:-translate-y-[115px] lg:-translate-y-[125px] rotate-[12deg] z-20",
    },
    {
      src: automotiveCatImg,
      alt: "Blush Leather",
      position:
        "translate-x-[0px] -translate-y-[40px] sm:-translate-y-[55px] md:translate-x-[0px] lg:translate-x-[10px] md:-translate-y-[70px] lg:-translate-y-[80px] rotate-[18deg] z-10",
    },
    {
      src: leatherGroupImg,
      alt: "Olive Green Leather",
      position:
        "-translate-x-[55px] -translate-y-[35px] sm:-translate-x-[80px] sm:-translate-y-[50px] md:-translate-x-[110px] lg:-translate-x-[130px] md:-translate-y-[60px] lg:-translate-y-[70px] -rotate-[20deg] z-10",
    },
  ];

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-[#ffffff] to-[#fffcf9] flex items-center justify-center px-4 py-8 sm:p-8 md:p-12">
      <div className="max-w-4xl w-full text-center">
        {/* Heading */}
        <h1 className="text-[10px] sm:text-xs md:text-sm lg:text-base font-light tracking-[2px] sm:tracking-[2.5px] md:tracking-[3px] leading-relaxed text-[#2c2c2c] mb-8 sm:mb-10 md:mb-12 lg:mb-16 uppercase max-w-2xl mx-auto px-2">
          A Material with Endless Possibilities, Rich in
          <br className="hidden sm:block" /> Tradition and History. Here at
          Gruppo Mastrotto,
          <br className="hidden sm:block" /> We Bring Out the Most Extraordinary
          Features of
          <br className="hidden sm:block" /> the Leather We Craft.
        </h1>

        {/* Leather Showcase */}
        <div className="relative h-48 sm:h-56 md:h-64 lg:h-80 mb-8 sm:mb-10 md:mb-12 lg:mb-16 flex items-center justify-center perspective-1000">
          <div className="relative w-full h-full animate-float">
            {leatherImages.map((leather, index) => (
              <div
                key={index}
                className={`absolute w-28 h-36 sm:w-32 sm:h-40 md:w-36 md:h-48 lg:w-44 lg:h-52 rounded-lg shadow-xl sm:shadow-2xl transition-all duration-500 hover:z-[60] hover:scale-105 hover:rotate-0 hover:-translate-y-3 sm:hover:-translate-y-5 cursor-pointer left-1/2 top-1/2 overflow-hidden ${leather.position}`}
              >
                <Image
                  src={leather.src}
                  alt={leather.alt}
                  fill
                  className="object-cover"
                  sizes="(max-width: 640px) 112px, (max-width: 768px) 128px, (max-width: 1024px) 144px, 176px"
                />
                {/* Overlay for depth effect */}
                <div className="absolute inset-0 bg-black/5 hover:bg-black/0 transition-all duration-300"></div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Button */}
        <button className="bg-gradient-to-br from-[#8b1538] to-[#a01c42] text-white px-6 py-3 sm:px-8 sm:py-3.5 md:px-10 md:py-4 lg:px-14 lg:py-5 rounded-full text-[10px] sm:text-xs md:text-sm tracking-[1.5px] sm:tracking-[2px] uppercase font-medium shadow-[0_6px_20px_rgba(139,21,56,0.4)] sm:shadow-[0_8px_30px_rgba(139,21,56,0.4)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_35px_rgba(139,21,56,0.5)] sm:hover:shadow-[0_12px_40px_rgba(139,21,56,0.5)] hover:from-[#a01c42] hover:to-[#8b1538] active:translate-y-0">
          Discover Our Leather Experience
        </button>
      </div>

      <style jsx>{`
        @keyframes float {
          0%,
          100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-8px);
          }
        }

        .animate-float {
          animation: float 6s ease-in-out infinite;
        }

        .perspective-1000 {
          perspective: 1000px;
        }

        @media (max-width: 640px) {
          @keyframes float {
            0%,
            100% {
              transform: translateY(0px);
            }
            50% {
              transform: translateY(-5px);
            }
          }
        }
      `}</style>
    </div>
  );
}
