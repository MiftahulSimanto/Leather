import React from "react";
import Image from "next/image";
import { leatherMeaningCover } from "@/assets";

const LeatherMeaningSection = () => {
  return (
    <section className="min-h-screen flex flex-col md:flex-row">
      {/* Left side with image */}
      <div className="flex-1 flex items-center justify-center shadow-md relative h-64 md:h-screen">
        <Image
          src={leatherMeaningCover}
          alt="Leather Meaning Cover"
          fill
          className="object-cover"
        />
      </div>

      {/* Right side with text */}
      <div className="flex-1 flex flex-col justify-center px-6 md:px-20 py-12 bg-white">
        <p className="text-sm text-gray-500 mb-2 uppercase">Definition</p>
        <h1 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
          What is Leather?
        </h1>
        <p className="text-gray-700 leading-relaxed mb-8">
          Leather is a material with a precise definition and specific
          characteristics. According to the standard{" "}
          <strong>ISO 15115:2019</strong>, the most important requirement is
          that the material must be of animal origin. Otherwise, it cannot be
          called leather.
          <br />
          <br />
          Materials often marketed as “synthetic leather,” “imitation leather,”
          or “faux leather” do not contain any animal or organic elements. These
          are entirely plastic-based products, typically PVC or polyurethane,
          with printed surfaces or films applied to mimic the look and feel of
          real leather.
        </p>
        <button className="bg-red-700 hover:bg-red-800 text-white font-semibold px-6 py-3 rounded-lg w-max transition">
          Learn More
        </button>
      </div>
    </section>
  );
};

export default LeatherMeaningSection;
