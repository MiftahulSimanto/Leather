"use client";
import React from "react";
import ContentImageSection from "../content-image-section";
import { leatherQualityCover } from "@/assets";

const BusinessPartnership = () => {
  return (
    <ContentImageSection
      title="Built for Long-Term Business Partnership"
      subTitle="05. Business Partnership"
      description="
        <p>We believe in building strong and lasting relationships with our buyers.</p>
        <p>Our commitment:</p>
        <ul class='grid gap-3 sm:grid-cols-2 mt-2'>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Transparent business practices</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Consistent quality standards</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Competitive pricing</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Timely communication</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm sm:col-span-2'>Reliable shipment scheduling</li>
        </ul>
        <p class='mt-4 rounded-lg border-l-4 border-neutral-900 bg-neutral-100 px-4 py-3 text-neutral-800'>
          Our goal is not just one order - but long-term cooperation.
        </p>
      "
      imageSrc={leatherQualityCover}
      imageAlt="Business Partnership"
    />
  );
};

export default BusinessPartnership;
