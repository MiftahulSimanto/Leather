"use client";
import React, { useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Autoplay } from "swiper/modules";
import { MdArrowBackIos, MdArrowForwardIos } from "react-icons/md";
import { Swiper as SwiperClass } from "swiper";

// Import Swiper styles
import "swiper/css";
import "swiper/css/navigation";
import DescriptionSection from "../description-section";

const PartnershipValue = () => {
  const prevRef = useRef<HTMLButtonElement>(null);
  const nextRef = useRef<HTMLButtonElement>(null);

  const slides = [
    { title: "65+", subtitle: "Years of Experience" },
    {
      title: "3",
      subtitle: "Business Units: Fashion, Interior Design, Automotive",
    },
    {
      title: "4",
      subtitle: "Business Units: Fashion, Interior Design, Automotive",
    },
    { title: "5", subtitle: "Possibilities of Use" },
  ];

  return (
    <section className="w-full min-h-screen flex flex-col bg-[#e8e4e1] py-16 px-4 md:px-20 ">
      {/* Top Section */}
      <DescriptionSection
        subTitle="  Leather Characteristics"
        title="1. Leather Sourcing & Procurement"
        description="
          <ul>
            <li><b>At Excellent Leather Agency</b>, we source high-quality leather directly from selected and reliable tanneries in Bangladesh.</li>
            <li>As an experienced leather sourcing agent in Bangladesh, we carefully identify suitable tanneries based on each buyer’s specific technical and commercial requirements.</li>
            <li>We negotiate competitive export prices, match exact specifications including thickness, grade, finish, and color, and coordinate complete order placement and confirmation with the supplier.</li>
            <li>Our structured sourcing process ensures that every buyer receives the right leather according to agreed standards, quality expectations, and international market demands.</li>
          </ul>
        "
      />

      {/* Bottom Slider */}
      <div className="bg-white w-full flex flex-col items-center justify-center relative rounded-4xl py-8 md:py-16">
        <div className="max-w-5xl w-full flex-1 flex items-center">
          <Swiper
            modules={[Navigation, Autoplay]}
            spaceBetween={30}
            slidesPerView={1.2}
            centeredSlides={true}
            loop={true}
            autoplay={{
              delay: 3000,
              disableOnInteraction: false,
              pauseOnMouseEnter: true,
            }}
            navigation={{
              prevEl: prevRef.current,
              nextEl: nextRef.current,
            }}
            onBeforeInit={(swiper: SwiperClass) => {
              if (
                swiper.params.navigation &&
                typeof swiper.params.navigation !== "boolean"
              ) {
                const navigation = swiper.params.navigation;
                navigation.prevEl = prevRef.current;
                navigation.nextEl = nextRef.current;
              }
            }}
            breakpoints={{
              0: { slidesPerView: 1, spaceBetween: 20 },
              640: { slidesPerView: 1.2, spaceBetween: 25 },
              768: { slidesPerView: 2, spaceBetween: 30 },
              1024: { slidesPerView: 3, spaceBetween: 40 },
            }}
            className="w-full"
          >
            {slides.map((item, idx) => (
              <SwiperSlide
                key={idx}
                className="flex items-center justify-center"
              >
                {({ isActive }) => (
                  <div
                    className={`flex flex-col items-center justify-center text-center px-4 md:px-6 py-6 md:py-10 bg-gray-50 rounded-2xl shadow-lg transition-transform duration-300 w-full hover:scale-105
                ${isActive ? "scale-105 opacity-100" : "scale-100 opacity-80"}`}
                  >
                    <h3 className="text-2xl md:text-4xl font-bold text-gray-900 mb-2">
                      {item.title}
                    </h3>
                    <p className="text-xs md:text-sm text-gray-600 uppercase tracking-widest">
                      {item.subtitle}
                    </p>
                  </div>
                )}
              </SwiperSlide>
            ))}
          </Swiper>
        </div>

        {/* Arrows */}
        <div className="w-full flex justify-end gap-4 mt-6 max-w-6xl px-4 md:px-0">
          <button
            ref={prevRef}
            className="bg-gray-200 p-3 rounded-full hover:bg-gray-300 transition"
          >
            <MdArrowBackIos className="text-gray-700 text-xl" />
          </button>
          <button
            ref={nextRef}
            className="bg-gray-200 p-3 rounded-full hover:bg-gray-300 transition"
          >
            <MdArrowForwardIos className="text-gray-700 text-xl" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default PartnershipValue;
