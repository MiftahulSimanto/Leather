"use client";

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence, useAnimation, Variants } from "framer-motion";
import { Menu, X, Rocket, Languages, ChevronRight } from "lucide-react";
import {
  FaBoxOpen,
  FaCookieBite,
  FaRegFaceSmile,
  FaRocket,
  FaUserShield,
} from "react-icons/fa6";
import { FaInfoCircle, FaPhoneAlt } from "react-icons/fa";
import Link from "next/link";
import { routesList } from "@/routes/routeList";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [hoveredItem, setHoveredItem] = useState<number | null>(null);
  const controls = useAnimation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "unset";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [menuOpen]);

  useEffect(() => {
    controls.start({
      y: 0,
      opacity: 1,
      transition: { duration: 0.6, ease: "easeOut" },
    });
  }, [controls]);

  const navLinks = [
    { name: "Express", href: "/express", icon: Rocket },
    { name: "Language", href: "/language", icon: Languages },
  ];

  const drawerNavLinks = [
    {
      name: "Services",
      href: "/services",
      icon: FaRocket,
      description: "Explore our premium services",
    },
    {
      name: "Products",
      href: "/products",
      icon: FaBoxOpen,
      description: "Browse our product catalog",
    },
    {
      name: "Leather Experience",
      href: "/leather-experience",
      icon: FaRegFaceSmile,
      description: "Discover the art of leather",
    },
    {
      name: "Privacy Policy",
      href: "/privacy-policy",
      icon: FaUserShield,
      description: "Your privacy matters to us",
    },
    {
      name: "Cookie Policy",
      href: "/cookie-policy",
      icon: FaCookieBite,
      description: "How we use cookies",
    },
    {
      name: "About Us",
      href: "/about-us",
      icon: FaInfoCircle,
      description: "Learn about our story",
    },
    {
      name: "Contact & Sales",
      href: "/contact-us",
      icon: FaPhoneAlt,
      description: "Get in touch with us",
    },
  ];

  const drawerVariants: Variants = {
    hidden: {},
    visible: { transition: { staggerChildren: 0.08, delayChildren: 0.15 } },
  };

  const itemVariants: Variants = {
    hidden: { opacity: 0, x: 30 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] },
    },
  };

  return (
    <>
      <motion.header
        initial={{ y: -30, opacity: 0 }}
        animate={controls}
        className={`fixed top-0 left-0 w-full z-50 px-6 py-4 transition-all duration-500 ${
          scrolled ? "bg-black/70 backdrop-blur-lg shadow-lg" : "bg-transparent"
        }`}
      >
        <div className="mx-auto max-w-7xl flex items-center justify-between">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link
              href={routesList.home}
              className="flex items-center gap-3 group h-[44px]"
            >
              <div className="relative w-10 h-10 flex items-center justify-center bg-gradient-to-br from-red-600 to-red-800 rounded-lg shadow-lg group-hover:shadow-red-500/50 transition-all duration-300">
                <span className="text-white font-bold text-xl">EL</span>
              </div>
              <span className="hidden md:flex text-2xl font-semibold tracking-tight text-white hover:text-white/90 transition-colors leading-none items-center">
                Excellent Leather Agency
              </span>
            </Link>
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-4">
            {/* Glass Capsule */}
            <motion.div
              animate={{
                backgroundColor: scrolled
                  ? "rgba(255,255,255,0.15)"
                  : "rgba(255,255,255,0.10)",
                backdropFilter: scrolled ? "blur(14px)" : "blur(10px)",
              }}
              whileHover={{
                scale: 1.02,
                boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
              }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="flex items-center gap-6 px-6 py-3 border border-white/20 rounded-full shadow-md"
            >
              {/* Desktop Nav Links */}
              <ul
                className={`hidden md:flex items-center gap-4 text-white font-medium ${
                  menuOpen ? "hidden" : "flex"
                }`}
              >
                {navLinks.map(({ name, href, icon: Icon }) => (
                  <motion.li
                    key={name}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-3 py-1 cursor-pointer transition-all duration-200 relative group"
                  >
                    <a href={href} className="flex items-center gap-2">
                      <Icon className="w-5 h-5" />
                      {name}
                    </a>
                    <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full" />
                  </motion.li>
                ))}
              </ul>

              {/* Menu Button */}
              <motion.button
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex gap-2 items-center text-white font-medium md:text-lg hover:text-white/90 transition-colors py-2 px-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  animate={{ rotate: menuOpen ? 90 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  {menuOpen ? (
                    <X className="w-5 h-5" />
                  ) : (
                    <Menu className="w-5 h-5" />
                  )}
                </motion.div>
                Menu
              </motion.button>
            </motion.div>
          </div>
        </div>
      </motion.header>

      {/* Enhanced Drawer */}
      <AnimatePresence>
        {menuOpen && (
          <>
            <motion.div
              key="overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
              onClick={() => setMenuOpen(false)}
            />

            <motion.div
              key="drawer"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="fixed top-0 right-0 h-screen w-full sm:w-[480px] lg:w-[55vw] bg-gradient-to-br from-gray-900 via-black to-gray-900 flex flex-col z-[70] shadow-2xl overflow-hidden"
            >
              {/* Header */}
              <div className="relative flex items-center justify-between p-6 border-b border-white/10">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <div className="flex-shrink-0">
                    <Link
                      href={routesList.home}
                      className="flex items-center gap-3 group h-[44px]"
                      onClick={() => setMenuOpen(false)}
                    >
                      <div className="relative w-10 h-10 flex items-center justify-center bg-gradient-to-br from-red-600 to-red-800 rounded-lg shadow-lg group-hover:shadow-red-500/50 transition-all duration-300">
                        <span className="text-white font-bold text-xl">EL</span>
                      </div>
                      <span className="hidden md:flex text-2xl font-semibold tracking-tight text-white hover:text-white/90 transition-colors leading-none items-center">
                        Excellent Leather Agency
                      </span>
                    </Link>
                  </div>
                </motion.div>
                <motion.button
                  onClick={() => setMenuOpen(false)}
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-all duration-200 backdrop-blur-sm border border-white/20"
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <X className="w-5 h-5" />
                </motion.button>
              </div>

              {/* Scrollable Links */}
              <div className="relative flex-1 overflow-y-auto custom-scrollbar">
                <motion.ul
                  variants={drawerVariants}
                  initial="hidden"
                  animate="visible"
                  className="flex flex-col gap-2 p-6"
                >
                  {drawerNavLinks.map(({ name, href }, index) => (
                    <motion.li
                      key={name}
                      variants={itemVariants}
                      onMouseEnter={() => setHoveredItem(index)}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <motion.a
                        href={href}
                        className="flex items-center gap-4 p-4 rounded-xl  transition-all duration-300 group"
                        onClick={() => setMenuOpen(false)}
                        whileHover={{ x: 8 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        {/* <motion.div
                            className="w-12 h-12 rounded-lg bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center shadow-lg group-hover:shadow-red-500/50 transition-all duration-300"
                            animate={{
                              rotate: hoveredItem === index ? 360 : 0,
                              scale: hoveredItem === index ? 1.1 : 1,
                            }}
                            transition={{ duration: 0.5 }}
                          >
                            <Icon className="w-6 h-6 text-white" />
                          </motion.div> */}
                        <div className="flex-1">
                          <div className="text-white font-semibold text-lg group-hover:text-red-400 transition-colors">
                            {name}
                          </div>
                        </div>
                        <motion.div
                          animate={{ x: hoveredItem === index ? 5 : 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
                        </motion.div>
                      </motion.a>
                    </motion.li>
                  ))}
                </motion.ul>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.05);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(239, 68, 68, 0.5);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(239, 68, 68, 0.7);
        }
      `}</style>
    </>
  );
};

export default Navbar;
