"use client";
import React from "react";
import { motion } from "framer-motion";
import { ArrowUp, Mail, Phone, MapPin } from "lucide-react";
import { FaLinkedin, FaInstagram, FaFacebook, FaVimeoV } from "react-icons/fa";

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const sections = [
    {
      title: "Products",
      links: [
        "Fashion",
        "Automotive",
        "Interior & Design",
        "Aviation",
        "Nautical",
        "Regenerated Materials",
      ],
    },
    {
      title: "Company",
      links: ["About Us", "The Leather", "News & Updates", "Careers"],
    },
    {
      title: "Resources",
      links: [
        "Headquarters in Italy",
        "Foreign Offices",
        "Dealers Network",
        "Code of Ethics",
      ],
    },
  ];

  const socialLinks = [
    { icon: FaLinkedin, href: "#", label: "LinkedIn" },
    { icon: FaInstagram, href: "#", label: "Instagram" },
    { icon: FaFacebook, href: "#", label: "Facebook" },
    { icon: FaVimeoV, href: "#", label: "Vimeo" },
  ];

  return (
    <footer className="bg-neutral-900 text-white relative">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-6 md:px-10 py-16 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-4 space-y-6">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-neutral-100 to-neutral-300 rounded-lg flex items-center justify-center">
                <span className="text-neutral-900 font-bold text-xl">EL</span>
              </div>
              <span className="text-xl font-light tracking-tight">
                Excellent Leather Agency
              </span>
            </div>

            {/* Description */}
            <p className="text-neutral-400 leading-relaxed text-sm max-w-sm">
              Crafting premium leather goods with uncompromising quality and
              timeless elegance since decades.
            </p>

            {/* Social Links */}
            <div className="flex gap-4 pt-4">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  whileHover={{ y: -3 }}
                  className="w-10 h-10 rounded-full bg-neutral-800 hover:bg-neutral-700
                           flex items-center justify-center transition-colors duration-300"
                >
                  <social.icon className="w-5 h-5 text-neutral-300" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          {sections.map((section, index) => (
            <div key={index} className="lg:col-span-2 space-y-4">
              <h3 className="text-sm font-medium uppercase tracking-wider text-neutral-400 mb-4">
                {section.title}
              </h3>
              <ul className="space-y-3">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href="#"
                      className="text-sm text-neutral-300 hover:text-white transition-colors
                               duration-200 inline-block hover:translate-x-1 transform"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Contact Column */}
          <div className="lg:col-span-4 space-y-5">
            <h3 className="text-sm font-medium uppercase tracking-wider text-neutral-400 mb-4">
              Contact Us
            </h3>

            <div className="space-y-4">
              {/* Address */}
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-neutral-400 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-neutral-300 leading-relaxed">
                  Via Quarta Strada 7<br />
                  36071 Arzignano, Vicenza
                  <br />
                  Italy
                </div>
              </div>

              {/* Email */}
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-neutral-400 flex-shrink-0" />
                <a
                  href="mailto:info@excellentleather.com"
                  className="text-sm text-neutral-300 hover:text-white transition-colors"
                >
                  info@excellentleather.com
                </a>
              </div>

              {/* Phone */}
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-neutral-400 flex-shrink-0" />
                <a
                  href="tel:+390444621200"
                  className="text-sm text-neutral-300 hover:text-white transition-colors"
                >
                  +39 0444 621200
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-neutral-800">
        <div className="max-w-7xl mx-auto px-6 md:px-10 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Copyright */}
            <p className="text-sm text-neutral-500">
              © 2025 Excellent Leather Agency. All rights reserved.
            </p>

            {/* Legal Links */}
            <div className="flex gap-6">
              <a
                href="#"
                className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors"
              >
                Privacy Policy
              </a>
              <a
                href="#"
                className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors"
              >
                Cookie Policy
              </a>
              <a
                href="#"
                className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors"
              >
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Back to Top Button */}
      <motion.button
        onClick={scrollToTop}
        whileHover={{ y: -3 }}
        whileTap={{ y: 0 }}
        className="fixed bottom-8 right-8 w-12 h-12 bg-white text-neutral-900 rounded-full
                 shadow-xl hover:shadow-2xl flex items-center justify-center
                 transition-shadow duration-300 group z-50"
        aria-label="Back to Top"
      >
        <ArrowUp className="w-5 h-5 group-hover:translate-y-[-2px] transition-transform" />
      </motion.button>
    </footer>
  );
}
