// hoc/withShutter.tsx
"use client";

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { usePathname, useRouter } from "next/navigation";

const withShutter = <P extends object>(
  WrappedComponent: React.ComponentType<P>
) => {
  const HOC = (props: P) => {
    const pathname = usePathname();
    const router = useRouter();

    const [mounted, setMounted] = useState(false);
    const [shutterState, setShutterState] = useState<
      "closed" | "opening" | "open"
    >("closed");
    const [nextPath, setNextPath] = useState<string | null>(null);

    // Client-only
    useEffect(() => setMounted(true), []);

    // Open shutter on first load
    useEffect(() => {
      if (!mounted) return;
      setShutterState("opening");
      const timer = setTimeout(() => setShutterState("open"), 800);
      return () => clearTimeout(timer);
    }, [mounted]);

    // Handle route changes
    const handleNavigation = (url: string) => {
      if (shutterState === "opening") return; // prevent double click
      setNextPath(url);
      setShutterState("closed"); // close shutter top->bottom
    };

    // Navigate after shutter closes
    useEffect(() => {
      if (shutterState === "closed" && nextPath) {
        router.push(nextPath);
        setNextPath(null);
        setShutterState("opening"); // open on new page
      }
    }, [shutterState, nextPath, router]);

    if (!mounted) return null;

    return (
      <>
        {/* Page content always rendered */}
        <motion.div
          key={pathname}
          initial={{ opacity: 0 }}
          animate={{ opacity: shutterState === "open" ? 1 : 0 }}
          transition={{ duration: 0.5 }}
        >
          <WrappedComponent {...props} navigate={handleNavigation} />
        </motion.div>

        {/* Shutter Overlay */}
        <AnimatePresence>
          {shutterState !== "open" && (
            <motion.div
              key={pathname}
              initial={{ height: shutterState === "closed" ? 0 : "100%" }}
              animate={{ height: shutterState === "closed" ? "100%" : 0 }}
              transition={{ duration: 0.8, ease: "easeInOut" }}
              className="fixed inset-0 bg-gray-900/90 z-[9999] pointer-events-auto"
              // bg-gray-900/90 = dark gray with 90% opacity
            />
          )}
        </AnimatePresence>
      </>
    );
  };

  return HOC;
};

export default withShutter;
