"use client";

import React from "react";
import Image from "next/image";
import DescriptionSection from "../description-section";
import { pinkProduct, blackProduct, redProduct } from "@/assets";

const FinishingAndEmbossingSection = () => {
  const images = [pinkProduct, blackProduct, redProduct];

  return (
    <section className="w-full flex flex-col bg-[#e8e4e1] py-16 px-4 md:px-16">
      <DescriptionSection
        subTitle="Accurate Documentation for Seamless Global Shipments"
        title="03. Export Documentation & Compliance"
        contentClassName="[&_p:first-of-type]:text-gray-700 [&_p:first-of-type]:text-[1.05rem] [&_p:first-of-type]:leading-relaxed [&_ul]:mt-2 [&_ul]:grid [&_ul]:gap-3 [&_ul]:sm:grid-cols-2 [&_li]:list-none [&_li]:rounded-xl [&_li]:border [&_li]:border-[#d9d3ce] [&_li]:bg-white [&_li]:px-4 [&_li]:py-3 [&_li]:text-sm [&_li]:font-medium [&_li]:text-gray-800 [&_li]:shadow-[0_1px_2px_rgba(0,0,0,0.05)] [&_li]:transition-all [&_li]:duration-200 [&_li:hover]:border-[#c3b9b1] [&_li:hover]:shadow-[0_8px_18px_rgba(0,0,0,0.08)] [&_p:last-of-type]:mt-4 [&_p:last-of-type]:rounded-lg [&_p:last-of-type]:border-l-4 [&_p:last-of-type]:border-[#8f6a52] [&_p:last-of-type]:bg-[#f6f3f1] [&_p:last-of-type]:px-4 [&_p:last-of-type]:py-3"
        description="
          <p>We handle complete export documentation to ensure smooth international transactions.:</p>
          <ul>
            <li>01. Pro-forma Invoice</li>
            <li>02. Commercial Invoice</li>
            <li>03. Packing List</li>
            <li>04. Bill of Lading</li>
            <li>05. Certificate of Origin</li>
            <li>06. Health Certificate</li>
            <li>07. Inspection Certificate (if required)</li>
            <li>08. Customs clearance documentation (SAFTA, AFTA, REX, etc.)</li>
          </ul>
        "
      />

      {/* Images row */}
      <div className="w-full flex flex-wrap gap-4 px-6 md:px-20 py-10 justify-center">
        {images.map((src, idx) => (
          <div
            key={idx}
            className="relative w-full sm:w-[45%] md:w-[30%] aspect-[9/16] rounded-lg overflow-hidden shadow-md"
          >
            <Image
              src={src}
              alt={`Finishing ${idx + 1}`}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 45vw, (max-width: 1024px) 30vw, 30vw"
            />
          </div>
        ))}
      </div>
      <div className="w-full max-w-6xl mx-auto px-6 md:px-8 mt-2">
        <div className="rounded-xl border-l-4 border-[#8f6a52] bg-[#f6f3f1] px-4 py-3 text-gray-800 text-sm md:text-base leading-relaxed">
          We ensure all paperwork complies with international trade regulations
          and buyer requirements.
        </div>
      </div>
    </section>
  );
};

export default FinishingAndEmbossingSection;
