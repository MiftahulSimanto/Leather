"use client";

import React from "react";
import Image from "next/image";
import { weCover } from "@/assets";

const AboutUs = () => {
  return (
    <section className="relative flex flex-col-reverse lg:flex-row items-center justify-between px-6 md:px-12 lg:px-32 py-12 lg:py-24 w-full bg-gradient-to-b from-[#f5f2ef] to-[#e8e4e1] gap-10 lg:gap-20">
      {/* Left Content */}
      <div
        className="flex-1 flex flex-col justify-center gap-4 md:gap-8 text-center lg:text-left
                      relative z-10 lg:z-auto -mt-16 lg:mt-0"
      >
        {/* Subtitle */}
        <p className="text-xs sm:text-sm md:text-base text-gray-500 uppercase tracking-wider">
          About Us
        </p>

        {/* Main Heading */}
        <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold text-gray-900 leading-snug md:leading-tight">
          Crafting Leather with Precision, Passion & Purpose
        </h1>

        {/* Description */}
        <p className="text-gray-700 text-sm sm:text-base md:text-lg leading-relaxed md:leading-loose max-w-full lg:max-w-3xl">
          For decades, we have dedicated ourselves to mastering the art of
          leather craftsmanship. Our journey is built on a commitment to
          tradition, innovation, and sustainability — creating products that not
          only endure, but also inspire. Every piece we produce reflects the
          skills of our artisans and the trust of our clients worldwide.
        </p>

        {/* CTA Button */}
        <div className="mt-4 md:mt-8">
          <a
            href="#team"
            className="inline-block px-6 sm:px-8 py-3 sm:py-4 bg-gray-900 text-white rounded-xl font-semibold text-sm sm:text-base md:text-lg hover:bg-gray-800 transition duration-300 shadow-md hover:shadow-lg"
          >
            Meet Our Team
          </a>
        </div>
      </div>

      {/* Right Image */}
      <div className="flex-1 w-full flex justify-center items-center mb-6 lg:mb-0 relative">
        <div className="relative w-full max-w-md sm:max-w-lg aspect-[9/16] lg:aspect-[4/5] rounded-3xl overflow-hidden shadow-xl">
          <Image
            src={weCover}
            alt="Our leather craftsmanship"
            fill
            className="object-cover object-center"
            priority
          />
        </div>

        {/* Overlay for mobile */}
        <div className="absolute inset-0  to-transparent lg:hidden rounded-3xl"></div>
      </div>
    </section>
  );
};

export default AboutUs;
