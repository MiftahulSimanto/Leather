"use client";

import React from "react";
import Image from "next/image";
import { automotiveImg, fashionImg, interiorDesignImg } from "@/assets";

const OurTargetSector = () => {
  const images = [
    {
      src: fashionImg,
      alt: "Fashion Sector",
    },
    {
      src: interiorDesignImg,
      alt: "Interior Design Sector",
    },
    {
      src: automotiveImg,
      alt: "automotive Design Sector",
    },
  ];
  return (
    <section className="w-full flex flex-col items-center justify-center py-12 px-6 bg-gray-50 w-full min-h-screen">
      {/* Title */}
      <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-8 text-center">
        Our Target Sectors
      </h2>

      {/* Images */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-6xl w-full">
        {images.map((image, index) => (
          <div
            key={index}
            className="relative w-full min-h-[250px] sm:min-h-[300px] md:min-h-[550px] flex-1"
          >
            <Image
              src={image.src}
              alt={image.alt}
              fill
              className="object-cover rounded-xl shadow-md"
            />
          </div>
        ))}
      </div>
    </section>
  );
};

export default OurTargetSector;
