"use client";
import React from "react";
import { sustainabilityCover } from "@/assets";
import ContentImageSection from "../content-image-section";

const Index = () => {
  return (
    <ContentImageSection
      title=" Leather: an example of circular economy"
      subTitle="Sustainability"
      description="<p>
         As well as possessing unique and inimitable properties, leather is
            also an ally of sustainability. It is a natural, biodegradable and
            recyclable material. A by-product of the food and dairy chain, it is
            ennobled giving life to new items avoiding its disposal in landfills
            as organic waste.
            <br />
            <br />
            Moreover, at Gruppo Mastrotto, more than 93% of the waste that
            leather generates in its processing is reused in other product
            sectors (agriculture, pharmaceuticals, nutraceuticals, chemicals),
            constituting one of the most virtuous examples of circular economy.
        </p>"
      imageSrc={sustainabilityCover}
      imageAlt="Sustainability Cover"
      cta={{
        label: "Learn More ",
        onClick: () => {},
      }}
    />
  );
};

export default Index;
