"use client";
import React from "react";
import ContentImageSection from "../content-image-section";
import { leatherQualityCover } from "@/assets";

const QualityReadyDelivery = () => {
  return (
    <ContentImageSection
      position="rightToLeft"
      title="Multi-Stage Quality Inspection for Export-Ready Leather"
      subTitle="02. Quality Inspection & Control"
      description="Quality is our highest priority in every leather export shipment. We conduct strict inspection procedures at multiple stages, beginning with pre-production material checking and continuing with in-line inspection during processing. Our own experienced technicians and professional leather selectors supervise thickness and measurement verification, color consistency checking, surface grading, and finishing evaluation to ensure compliance with buyer specifications. Before shipment, we perform a detailed final pre-shipment inspection, including packing verification, to confirm that all goods meet the required standards. Only after full quality approval do we authorize the shipment for export."
      imageSrc={leatherQualityCover}
      imageAlt="Quality Delivery"
      cta={{
        label: "Learn More about the service",
        onClick: () => console.log("CTA Clicked"),
      }}
    />
  );
};

export default QualityReadyDelivery;
