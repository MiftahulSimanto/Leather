"use client";

import React from "react";
import DescriptionSection from "../description-section";

import CategoryList from "./CategoryList";

type CategoryLayoutProps = {
  categories: ICategory[];
};

const CategoryLayout = ({ categories }: CategoryLayoutProps) => {
  return (
    <section className="bg-[#f4f0ed] py-16 px-4 md:px-8">
      <DescriptionSection
        subTitle="Leather Craftsmanship excelling in every detail"
        title="Solutions"
        description="<p> Our finishing techniques are unique processes that highlight the natural characteristics of the leather and create customisations designed to enhance every project. The main aim is to boost performance (resistance to abrasion, light fastness, gloss, feel, etc.) and adjust the final color.</p>
         <p> Embossing then makes it possible to decorate the leathers, finishing techniques are unique processes, creating raised patterns on the surface, generating exclusive motifs and distinctive textures.  </p>
                  <p> Embossing then makes it possible to decorate the leathers, finishing techniques are unique processes, creating raised patterns on the surface, generating exclusive motifs and distinctive textures.  </p>
         "
      />
      <CategoryList categories={categories} />
    </section>
  );
};

export default CategoryLayout;
