"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

type Props = {
  categories: ICategory[];
};

const CategoryList = ({ categories }: Props) => {
  // Container variants for staggered children
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        when: "beforeChildren",
      },
    },
  };

  // Item variants for entrance animation
  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeInOut" as const,
      },
    },
    hover: {
      scale: 1.02,
      transition: { duration: 0.3 },
    },
  };

  // Image overlay variants
  const overlayVariants = {
    hover: {
      backgroundColor: "rgba(0,0,0,0.1)",
      transition: { duration: 0.5 },
    },
  };

  // Divider animation variants
  const dividerVariants = {
    hover: {
      width: "5rem",
      backgroundColor: "#111",
      transition: { duration: 0.5 },
    },
  };

  // Arrow motion variants
  const arrowVariants = {
    hover: { x: 4, transition: { duration: 0.3 } },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-100px" }}
      className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 px-4 md:px-6"
    >
      {categories?.map((category, index) => {
        const rowIndex = Math.floor(index / 2);
        const isFirstInRow = index % 2 === 0;

        // Zigzag pattern
        const colSpanClass =
          rowIndex % 2 === 0
            ? isFirstInRow
              ? "md:col-span-2"
              : "md:col-span-1"
            : isFirstInRow
              ? "md:col-span-1"
              : "md:col-span-2";

        return (
          <motion.div
            key={`${category.id}-${index}`}
            variants={itemVariants}
            whileHover="hover"
            className={`relative flex flex-col bg-white overflow-hidden transition-all duration-500 ${colSpanClass}`}
          >
            {/* Image Container */}
            <div className="relative w-full aspect-[4/3] overflow-hidden bg-neutral-100">
              <motion.div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${category.image})` }}
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.7 }}
              />
              <motion.div
                className="absolute inset-0"
                variants={overlayVariants}
              />
            </div>

            {/* Content */}
            <div className="flex flex-col flex-1 p-6 md:p-8 lg:p-10">
              {/* Title */}
              <h3 className="text-xl md:text-2xl font-light tracking-wide text-neutral-900 mb-4">
                {category.title}
              </h3>

              {/* Divider */}
              <motion.div
                className="w-12 h-px bg-neutral-300 mb-4"
                variants={dividerVariants}
              />

              {/* Description */}
              <p className="text-sm md:text-base leading-relaxed text-neutral-600 mb-6 flex-1">
                {category.description}
              </p>

              {/* CTA Link */}
              <motion.a
                href={category.href}
                className="inline-flex items-center gap-2 text-sm font-medium uppercase tracking-wider text-neutral-900"
                whileHover="hover"
              >
                <span className="relative">
                  Discover More
                  <motion.span
                    className="absolute bottom-0 left-0 w-full h-px bg-neutral-900 origin-left"
                    variants={{
                      hover: { scaleX: 1.1, transition: { duration: 0.3 } },
                    }}
                  />
                </span>
                <motion.span variants={arrowVariants}>
                  <ArrowRight className="w-4 h-4" />
                </motion.span>
              </motion.a>
            </div>
          </motion.div>
        );
      })}
    </motion.div>
  );
};

export default CategoryList;
