"use client";

import React from "react";
import Image from "next/image";

// Example images (replace with your own)
import {
  photo1,
  photo2,
  photo3,
  photo4,
  photo5,
  photo6,
  photo7,
} from "@/assets";

const PhotoGallery = () => {
  const images = [photo1, photo2, photo3, photo4, photo5, photo6, photo7];

  return (
    <section className="w-full px-60 py-20 bg-[#f5f2ef]">
      {/* Section Title */}
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-gray-800">Our Photo Gallery</h2>
        <p className="text-gray-600 mt-2">
          A collection of our favorite moments and highlights
        </p>
      </div>

      {/* Top row: 3 images */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        {images.slice(0, 3).map((img, index) => (
          <div
            key={index}
            className="relative w-full h-96 overflow-hidden rounded-xl shadow-md"
          >
            <Image
              src={img}
              alt={`Gallery Image ${index + 1}`}
              fill
              className="object-cover hover:scale-105 transition-transform duration-500"
              placeholder="blur"
            />
          </div>
        ))}
      </div>

      {/* Bottom row: 2 images side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        {images.slice(3, 5).map((img, index) => (
          <div
            key={index + 3}
            className="relative w-full h-96 overflow-hidden rounded-xl shadow-md lg:col-span-1"
          >
            <Image
              src={img}
              alt={`Gallery Image ${index + 4}`}
              fill
              className="object-cover hover:scale-105 transition-transform duration-500"
              placeholder="blur"
            />
          </div>
        ))}
      </div>
    </section>
  );
};

export default PhotoGallery;
