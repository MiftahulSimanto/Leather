"use client";
import React from "react";
import ContentImageSection from "../content-image-section";
import { leatherQualityCover } from "@/assets";

const LogisticsAndShipment = () => {
  return (
    <ContentImageSection
      title="Factory-to-Port Logistics with End-to-End Shipment Control"
      subTitle="04. Logistics & Shipment Coordination"
      position="rightToLeft"
      description="
        <p>We coordinate shipment from factory to destination port.</p>
        <p>Our support includes:</p>
        <ul class='grid gap-3 sm:grid-cols-2 mt-2'>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Sea freight (FCL & LCL)</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Air freight for urgent orders</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>AWB (Master B/L)</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Freight forwarder coordination</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Container loading supervision</li>
          <li class='list-none rounded-xl border border-neutral-200 bg-white px-4 py-3 font-medium text-neutral-800 shadow-sm'>Shipment tracking and updates</li>
        </ul>
        <p class='mt-4 rounded-lg border-l-4 border-neutral-900 bg-neutral-100 px-4 py-3 text-neutral-800'>
          We ensure timely dispatch and proper handling of goods.
        </p>
      "
      imageSrc={leatherQualityCover}
      imageAlt="Quality Delivery"
    />
  );
};

export default LogisticsAndShipment;
