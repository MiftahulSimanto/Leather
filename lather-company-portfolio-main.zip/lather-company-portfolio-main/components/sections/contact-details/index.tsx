"use client";

import React, { useEffect, useState, useRef } from "react";
import {
  FaPhone,
  FaMobileAlt,
  FaFax,
  FaEnvelope,
  FaWhatsapp,
} from "react-icons/fa";
import { photo1 } from "@/assets";

const ContactDetails = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) setIsVisible(true);
      },
      { threshold: 0.2 }
    );

    const currentRef = sectionRef.current;
    if (currentRef) observer.observe(currentRef);

    return () => {
      if (currentRef) observer.unobserve(currentRef);
    };
  }, []);

  const contactItems = [
    {
      icon: <FaPhone size={18} />,
      title: "Phone",
      details: ["(880) 2-9631714"],
    },
    {
      icon: <FaMobileAlt size={18} />,
      title: "Cell",
      details: ["(880) 1817-513893"],
    },
    { icon: <FaFax size={18} />, title: "Fax", details: ["(880) 2-9140997"] },
    {
      icon: <FaEnvelope size={18} />,
      title: "Email",
      details: [
        "noyan@excellentleatheragency.com",
        "ela_bd@excellentleatheragency.com",
      ],
    },
    {
      icon: <FaWhatsapp size={18} />,
      title: "WhatsApp",
      details: ["+8801827936652"],
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen bg-center bg-cover flex items-center justify-center px-4 sm:px-6 md:px-12"
      style={{ backgroundImage: `url(${photo1.src})` }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/60 z-10"></div>

      {/* Content Card */}
      <div
        className={`relative z-20 w-full max-w-3xl mx-auto bg-white/10 backdrop-blur-md rounded-3xl p-6 md:p-10 shadow-2xl transform transition-all duration-1000
          ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }
        `}
      >
        <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-6 text-center">
          Contact with Us
        </h2>

        <p className="text-white/90 text-base md:text-lg mb-8 text-center">
          We supply all kinds of leather & leather goods from Bangladesh 🇧🇩 —
          Cow, Goat, Buffalo, and Sheep leather in all articles.
        </p>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {contactItems.map((item, idx) => (
            <div
              key={idx}
              className="flex items-center gap-3 p-3 md:p-4 rounded-xl bg-white/10 backdrop-blur-sm hover:bg-white/20 hover:scale-105 transition-transform duration-300 cursor-pointer"
            >
              <div className="bg-white/20 p-3 rounded-full text-white hover:text-yellow-400 transition-colors duration-300">
                {item.icon}
              </div>
              <div>
                <p className="text-white font-semibold text-sm md:text-base">
                  {item.title}
                </p>
                {item.details.map((d, i) => (
                  <p key={i} className="text-white/80 text-xs md:text-sm">
                    {d}
                  </p>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer / Address */}
        <div className="mt-6 md:mt-8 text-white/80 text-center space-y-1">
          <p className="text-sm md:text-base">
            <b>MR. NOYAN AHMED</b>
          </p>
          <p className="text-xs md:text-sm">
            40/1, Moneshwer Road, Zigatola, Tannery More,
            <br />
            Hazaribagh, Dhaka-1209, Bangladesh
          </p>
          <p className="text-sm md:text-base">
            <b>Contact Person:</b> Nazirul Suny
          </p>
        </div>
      </div>
    </section>
  );
};

export default ContactDetails;
