import ContactUsComp from "@/components/pages/contact-us";
import React from "react";

const ContactUs = () => {
  return <ContactUsComp />;
};

export default ContactUs;
