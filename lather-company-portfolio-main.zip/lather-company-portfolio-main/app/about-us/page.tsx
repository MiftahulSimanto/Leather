import AboutUsComp from "@/components/pages/about-us";
import React from "react";

const AboutUs = () => {
  return <AboutUsComp />;
};

export default AboutUs;
