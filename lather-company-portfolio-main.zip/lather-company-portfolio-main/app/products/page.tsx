import ProductsComp from "@/components/pages/products";
import React from "react";

const ProductsPage = () => {
  return <ProductsComp />;
};

export default ProductsPage;
