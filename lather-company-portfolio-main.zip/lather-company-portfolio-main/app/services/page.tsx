import ServicesComp from "@/components/pages/services";
import React from "react";

const ServicesPage = () => {
  return <ServicesComp />;
};

export default ServicesPage;
