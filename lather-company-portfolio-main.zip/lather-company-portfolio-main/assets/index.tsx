//logo
export { default as Logo } from "./logo/ela.png";

//others
export { default as leatherExperienceMaking } from "./others/leather-experience-making.avif";
export { default as leatherPelle } from "./others/leather-pelle.avif";
export { default as sustainabilityCover } from "./others/sustainability-cover.jpg";
export { default as leatherQualityCover } from "./others/leather-quality.jpg";
export { default as leatherMeaningCover } from "./others/leather-meaning.jpg";
export { default as weCover } from "./others/we.jpg";
export { default as withClient } from "./others/withClient.jpg";
export { default as peopleImg } from "./others/people.jpg";
export { default as productProcessingImg } from "./others/product-processing.jpg";
export { default as packingAndDeliveryImg } from "./others/packing-and-delivery.jpg";
export { default as leatherGroupImg } from "./others/leather-group.jpg";

//products
export { default as pinkProduct } from "./others/pink-product.jpg";
export { default as blackProduct } from "./others/black-product.jpg";
export { default as redProduct } from "./others/red-product.jpg";
export { default as lather3 } from "./others/lather-3.jpg";

//sector
export { default as fashionImg } from "./others/fashion.avif";
export { default as interiorDesignImg } from "./others/interiorDesign.avif";
export { default as automotiveImg } from "./others/automotive.avif";

//products
export { default as photo1 } from "./products/product-1.jpg";
export { default as photo2 } from "./products/product-2.jpg";
export { default as photo3 } from "./products/product-3.jpg";
export { default as photo4 } from "./products/product-4.jpg";
export { default as photo5 } from "./products/product-5.jpg";
export { default as photo6 } from "./products/product-6.jpg";
export { default as photo7 } from "./products/product-7.jpg";

export { default as automotiveCatImg } from "./categories/automotive.avif";
export { default as aviationCatImg } from "./categories/aviation.avif";
export { default as fashionCatImg } from "./categories/fashion.avif";
export { default as interiorDesignCatImg } from "./categories/interior-design.avif";
export { default as materialsCatImg } from "./categories/materials.avif";
export { default as nauticalCatImg } from "./categories/nautical.avif";
