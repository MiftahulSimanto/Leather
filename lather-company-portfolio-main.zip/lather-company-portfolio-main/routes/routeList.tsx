export const routesList = {
  home: "/",
  contactUs: "/contact-us",
  cookiePolicy: "/cookie-policy",
  leatherExperience: "/leather-experience",
  privacyPolicy: "/privacy-policy",
  products: "/products",
  services: "/services",
  aboutUs: "/about-us",
};
